package com.example.htmleditor

import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class GitHubApiClient(
    private val repo: String, // e.g. "username/repo"
    private val token: String // GitHub PAT
) {

    data class WorkflowRunInfo(
        val id: Long,
        val status: String,       // "queued", "in_progress", "completed"
        val conclusion: String?   // "success", "failure", null
    )

    private fun openConnection(endpoint: String, method: String = "GET"): HttpURLConnection {
        val url = if (endpoint.startsWith("http")) URL(endpoint) else URL("https://api.github.com$endpoint")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        conn.setRequestProperty("User-Agent", "HTMLEditorApp-Android")
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        return conn
    }

    /**
     * Checks if file exists on GitHub to obtain its SHA (required for updating via Contents API).
     */
    private fun getFileSha(path: String): String? {
        return try {
            val conn = openConnection("/repos/$repo/contents/$path")
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                json.optString("sha")
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Checks if the workflow file exists in the repository.
     */
    fun checkWorkflowExists(): Boolean {
        return try {
            val conn = openConnection("/repos/$repo/contents/.github/workflows/build-standalone-apk.yml")
            conn.responseCode == 200
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Pushes build payload JSON to the GitHub repo, automatically triggering the build workflow.
     */
    fun uploadBuildPayload(payloadJson: String): Boolean {
        val path = "build_payload/payload.json"
        val existingSha = getFileSha(path)

        val encodedContent = Base64.encodeToString(payloadJson.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val body = JSONObject().apply {
            put("message", "Trigger Standalone APK Build")
            put("content", encodedContent)
            if (!existingSha.isNullOrEmpty()) {
                put("sha", existingSha)
            }
        }

        val conn = openConnection("/repos/$repo/contents/$path", "PUT")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        return code in 200..201
    }

    /**
     * Fetches the latest workflow run for the standalone APK builder.
     */
    fun getLatestWorkflowRun(): WorkflowRunInfo? {
        val conn = openConnection("/repos/$repo/actions/workflows/build-standalone-apk.yml/runs?per_page=1")
        if (conn.responseCode != 200) return null

        val response = conn.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(response)
        val runs = json.optJSONArray("workflow_runs")
        if (runs == null || runs.length() == 0) return null

        val latest = runs.getJSONObject(0)
        return WorkflowRunInfo(
            id = latest.getLong("id"),
            status = latest.getString("status"),
            conclusion = if (latest.isNull("conclusion")) null else latest.getString("conclusion")
        )
    }

    /**
     * Fetches the release download URL for a completed standalone APK build.
     */
    fun getReleaseDownloadUrl(runNumber: Long): String? {
        val tag = "standalone-build-$runNumber"
        val conn = openConnection("/repos/$repo/releases/tags/$tag")
        if (conn.responseCode != 200) return null

        val response = conn.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(response)
        val assets = json.optJSONArray("assets") ?: return null

        for (i in 0 until assets.length()) {
            val asset = assets.getJSONObject(i)
            val name = asset.optString("name")
            if (name.endsWith(".apk", ignoreCase = true)) {
                return asset.optString("browser_download_url")
            }
        }
        return null
    }

    /**
     * Downloads the APK file to the specified local file destination.
     */
    fun downloadApk(urlStr: String, destinationFile: File, onProgress: ((Int) -> Unit)? = null): Boolean {
        destinationFile.parentFile?.mkdirs()
        var conn: HttpURLConnection = openConnection(urlStr)
        var responseCode = conn.responseCode

        // Handle HTTP 302 redirects from GitHub releases to AWS S3
        if (responseCode == HttpURLConnection.HTTP_MOVED_TEMP || responseCode == HttpURLConnection.HTTP_MOVED_PERM) {
            val redirectedUrl = conn.getHeaderField("Location")
            conn = URL(redirectedUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            responseCode = conn.responseCode
        }

        if (responseCode != HttpURLConnection.HTTP_OK) return false

        val totalBytes = conn.contentLength
        var downloadedBytes = 0

        conn.inputStream.use { input ->
            FileOutputStream(destinationFile).use { output ->
                val buffer = ByteArray(8192)
                var bytesRead: Int
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    output.write(buffer, 0, bytesRead)
                    downloadedBytes += bytesRead
                    if (totalBytes > 0 && onProgress != null) {
                        val progress = (downloadedBytes * 100L / totalBytes).toInt()
                        onProgress(progress)
                    }
                }
            }
        }
        return true
    }
}
