package com.example.htmleditor

import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class GitHubApiClient(
    private val repo: String, // e.g. "username/repo"
    private val token: String // GitHub PAT
) {

    data class WorkflowRunInfo(
        val id: Long,
        val status: String,       // "queued", "in_progress", "completed"
        val conclusion: String?   // "success", "failure", null
    )

    private fun openConnection(endpoint: String, method: String = "GET"): HttpURLConnection {
        val url = if (endpoint.startsWith("http")) URL(endpoint) else URL("https://api.github.com$endpoint")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        conn.setRequestProperty("User-Agent", "HTMLEditorApp-Android")
        conn.connectTimeout = 30000
        conn.readTimeout = 60000
        return conn
    }

    /**
     * Checks if file exists on GitHub to obtain its SHA (required for updating via Contents API).
     */
    fun getFileSha(path: String): String? {
        return try {
            val conn = openConnection("/repos/$repo/contents/$path")
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                json.optString("sha")
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Checks if the workflow file exists in the repository.
     */
    fun checkWorkflowExists(): Boolean {
        return try {
            val conn = openConnection("/repos/$repo/contents/.github/workflows/build-standalone-apk.yml")
            conn.responseCode == 200
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Uploads any file bytes to the specified path in the GitHub repository.
     */
    fun uploadFile(path: String, contentBytes: ByteArray, commitMessage: String): Boolean {
        val existingSha = getFileSha(path)
        val encodedContent = Base64.encodeToString(contentBytes, Base64.NO_WRAP)
        val body = JSONObject().apply {
            put("message", commitMessage)
            put("content", encodedContent)
            if (!existingSha.isNullOrEmpty()) {
                put("sha", existingSha)
            }
        }

        val conn = openConnection("/repos/$repo/contents/$path", "PUT")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        return code in 200..201
    }

    /**
     * Pushes build payload JSON to the GitHub repo, automatically triggering the build workflow.
     */
    fun uploadBuildPayload(payloadJson: String): Boolean {
        val path = "build_payload/payload.json"
        val existingSha = getFileSha(path)

        val encodedContent = Base64.encodeToString(payloadJson.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val body = JSONObject().apply {
            put("message", "Trigger Standalone APK Build")
            put("content", encodedContent)
            if (!existingSha.isNullOrEmpty()) {
                put("sha", existingSha)
            }
        }

        val conn = openConnection("/repos/$repo/contents/$path", "PUT")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        if (code !in 200..201) {
            val err = try { conn.errorStream?.bufferedReader()?.use { it.readText() } } catch (_: Exception) { null }
            android.util.Log.e("GitHubApiClient", "uploadBuildPayload failed: HTTP $code - $err")
        }
        return code in 200..201
    }

    /**
     * Fetches the latest workflow run for the standalone APK builder.
     */
    fun getLatestWorkflowRun(): WorkflowRunInfo? {
        val conn = openConnection("/repos/$repo/actions/workflows/build-standalone-apk.yml/runs?per_page=1")
        if (conn.responseCode != 200) return null

        val response = conn.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(response)
        val runs = json.optJSONArray("workflow_runs")
        if (runs == null || runs.length() == 0) return null

        val latest = runs.getJSONObject(0)
        return WorkflowRunInfo(
            id = latest.getLong("id"),
            status = latest.getString("status"),
            conclusion = if (latest.isNull("conclusion")) null else latest.getString("conclusion")
        )
    }

    /**
     * Fetches the release download URL for the latest completed standalone APK build.
     * Returns the API asset URL (which works for both public and private repos) or fallback browser URL.
     */
    fun getReleaseDownloadUrl(): String? {
        try {
            val conn = openConnection("/repos/$repo/releases/latest")
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val assets = json.optJSONArray("assets")
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val asset = assets.getJSONObject(i)
                        val name = asset.optString("name")
                        if (name.endsWith(".apk", ignoreCase = true)) {
                            val apiUrl = asset.optString("url")
                            if (!apiUrl.isNullOrEmpty()) {
                                return apiUrl
                            }
                            return asset.optString("browser_download_url")
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // Fallback: query recent releases
        try {
            val conn = openConnection("/repos/$repo/releases?per_page=3")
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val array = org.json.JSONArray(response)
                for (i in 0 until array.length()) {
                    val rel = array.getJSONObject(i)
                    val assets = rel.optJSONArray("assets") ?: continue
                    for (j in 0 until assets.length()) {
                        val asset = assets.getJSONObject(j)
                        val name = asset.optString("name")
                        if (name.endsWith(".apk", ignoreCase = true)) {
                            val apiUrl = asset.optString("url")
                            if (!apiUrl.isNullOrEmpty()) {
                                return apiUrl
                            }
                            return asset.optString("browser_download_url")
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return null
    }

    /**
     * Checks if a release already exists on GitHub for the given project fingerprint.
     */
    fun findReleaseByFingerprint(fingerprint: String): String? {
        if (fingerprint.isBlank()) return null
        try {
            val conn = openConnection("/repos/$repo/releases?per_page=10")
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val array = org.json.JSONArray(response)
                for (i in 0 until array.length()) {
                    val rel = array.getJSONObject(i)
                    val body = rel.optString("body")
                    val name = rel.optString("name")
                    if (body.contains(fingerprint) || name.contains(fingerprint)) {
                        val assets = rel.optJSONArray("assets") ?: continue
                        for (j in 0 until assets.length()) {
                            val asset = assets.getJSONObject(j)
                            val aName = asset.optString("name")
                            if (aName.endsWith(".apk", ignoreCase = true)) {
                                val apiUrl = asset.optString("url")
                                if (!apiUrl.isNullOrEmpty()) {
                                    return apiUrl
                                }
                                return asset.optString("browser_download_url")
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return null
    }

    /**
     * Downloads the APK file to destination handling redirects cleanly without S3/Azure auth conflict.
     */
    fun downloadApk(urlStr: String, destinationFile: File, onProgress: ((Int) -> Unit)? = null): Boolean {
        destinationFile.parentFile?.mkdirs()
        var currentUrl = urlStr
        var redirectCount = 0

        while (redirectCount < 8) {
            val url = URL(currentUrl)
            val conn = url.openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 25000
            conn.readTimeout = 35000
            conn.setRequestProperty("User-Agent", "HTMLEditorApp-Android")

            // ONLY send GitHub Authorization and octet-stream to api.github.com.
            // Never send Authorization to github.com or redirected storage (Azure/AWS S3).
            if (url.host.equals("api.github.com", ignoreCase = true)) {
                conn.setRequestProperty("Accept", "application/octet-stream")
                if (token.isNotEmpty()) {
                    conn.setRequestProperty("Authorization", "Bearer $token")
                }
                conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            }

            val code = conn.responseCode
            if (code == 301 || code == 302 || code == 307 || code == 308) {
                val location = conn.getHeaderField("Location") ?: return false
                conn.disconnect()
                currentUrl = location
                redirectCount++
                continue
            }

            if (code != 200) {
                conn.disconnect()
                return false
            }

            val totalBytes = conn.contentLength
            var downloadedBytes = 0

            conn.inputStream.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        downloadedBytes += bytesRead
                        if (totalBytes > 0 && onProgress != null) {
                            val progress = (downloadedBytes * 100L / totalBytes).toInt()
                            onProgress(progress)
                        }
                    }
                }
            }
            conn.disconnect()
            return destinationFile.exists() && destinationFile.length() > 0
        }
        return false
    }
}
