package com.example.htmleditor

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var projectManager: ProjectManager
    private lateinit var editorWebView: WebView
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var fileListRecyclerView: RecyclerView
    private lateinit var fileListAdapter: FileListAdapter
    private lateinit var tabRecyclerView: RecyclerView
    private lateinit var tabAdapter: EditorTabAdapter
    private lateinit var emptyTabsText: TextView
    private lateinit var standaloneApkBuilder: StandaloneApkBuilder

    private var currentOpenFile: File? = null
    private var editorReady = false
    private var pendingContentToLoad: Pair<String, String>? = null // content, lang

    private var currentAppMode: String = "dark"
    private var currentEditorTheme: String = "dark"

    // ---- Activity result launchers ----

    private val openZipLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { handleZipImport(it) }
    }

    private val openFilesLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) handleMultiFileImport(uris)
    }

    private var pendingSaveAsContent: String? = null

    private val saveAsDocumentLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("text/html")
    ) { uri: Uri? ->
        uri?.let { destUri ->
            pendingSaveAsContent?.let { content ->
                try {
                    contentResolver.openOutputStream(destUri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    }
                    val fileName = queryFileName(destUri) ?: "file.html"
                    toast("✅ Saved to Phone Storage:\n$fileName")
                } catch (e: Exception) {
                    toast("Failed to save to phone: ${e.message}")
                }
            }
        }
    }

    private val pickIconLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { standaloneApkBuilder.setPickedIcon(it) }
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projectManager = ProjectManager(this)
        standaloneApkBuilder = StandaloneApkBuilder(this).apply {
            onPickIconRequested = { pickIconLauncher.launch("image/*") }
        }

        drawerLayout = findViewById(R.id.drawerLayout)
        editorWebView = findViewById(R.id.editorWebView)
        fileListRecyclerView = findViewById(R.id.fileListRecyclerView)
        tabRecyclerView = findViewById(R.id.tabRecyclerView)
        emptyTabsText = findViewById(R.id.emptyTabsText)

        loadThemePreferences()

        val topToolbar = findViewById<MaterialToolbar>(R.id.topToolbar)
        topToolbar.setNavigationOnClickListener {
            drawerLayout.openDrawer(androidx.core.view.GravityCompat.START)
        }
        topToolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_build_standalone_apk -> { promptBuildStandaloneApk(); true }
                R.id.action_theme_settings -> { showThemeDialog(); true }
                R.id.action_github_settings -> { standaloneApkBuilder.showSettingsDialog(); true }
                R.id.action_how_to_use -> { startActivity(Intent(this, OnboardingActivity::class.java)); true }
                R.id.action_save_as_phone -> { saveAsToPhoneStorage(); true }
                R.id.action_save_as_project -> { saveAsInProject(); true }
                R.id.action_manage_projects -> { showProjectManagerDialog(); true }
                R.id.action_new_project -> { promptNewProjectName(); true }
                R.id.action_export_downloads -> { exportProjectToDownloadsFolder(); true }
                R.id.action_copy_all -> { copyAllContent(); true }
                R.id.action_delete_all -> { deleteAllContent(); true }
                R.id.action_rename -> { renameCurrentFile(); true }
                R.id.action_delete -> { deleteCurrentFile(); true }
                R.id.action_share_zip -> { exportProjectZip(); true }
                else -> false
            }
        }

        setupTabs()
        setupEditorWebView()
        setupFileList()
        setupBottomButtons()
        setupQuickInsertBar()
        applyAppTheme(currentAppMode == "light")

        // Load any existing project files on start
        refreshFileList()
        val existingFiles = projectManager.listProjectFiles()
        if (existingFiles.isNotEmpty()) {
            val main = projectManager.findMainHtmlFile() ?: existingFiles.first()
            openFileInEditor(main)
        } else {
            updateEmptyTabsState()
        }
    }

    // ================= Tab Bar setup =================

    private fun setupTabs() {
        tabAdapter = EditorTabAdapter(
            onTabClick = { file -> switchToFile(file) },
            onTabClose = { file -> closeTab(file) }
        )
        tabRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tabRecyclerView.adapter = tabAdapter
    }

    private fun updateEmptyTabsState() {
        if (tabAdapter.itemCount == 0) {
            emptyTabsText.visibility = View.VISIBLE
            tabRecyclerView.visibility = View.GONE
        } else {
            emptyTabsText.visibility = View.GONE
            tabRecyclerView.visibility = View.VISIBLE
        }
    }

    // ================= Editor WebView setup =================

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun setupEditorWebView() {
        editorWebView.isFocusable = true
        editorWebView.isFocusableInTouchMode = true
        editorWebView.settings.javaScriptEnabled = true
        editorWebView.settings.domStorageEnabled = true
        editorWebView.addJavascriptInterface(EditorBridge(), "AndroidBridge")
        editorWebView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                editorReady = true
                applyEditorTheme(currentEditorTheme)
                pendingContentToLoad?.let { (content, lang) ->
                    loadContentIntoEditor(content, lang)
                    pendingContentToLoad = null
                }
            }
        }

        editorWebView.setOnTouchListener { v, _ ->
            if (!v.hasFocus()) {
                v.requestFocus()
            }
            false
        }

        editorWebView.loadUrl("file:///android_asset/editor/index.html")
    }

    inner class EditorBridge {
        @JavascriptInterface
        fun onContentChanged() {
            // Unsaved indicator hook
        }
    }

    private fun loadContentIntoEditor(content: String, lang: String) {
        val escaped = org.json.JSONObject.quote(content)
        editorWebView.evaluateJavascript("setContent($escaped, '$lang')", null)
    }

    private fun getEditorContent(callback: (String) -> Unit) {
        editorWebView.evaluateJavascript("getContent()") { result ->
            val unquoted = try {
                org.json.JSONTokener(result).nextValue() as String
            } catch (e: Exception) {
                result.trim('"')
            }
            callback(unquoted)
        }
    }

    private fun langForFile(file: File): String = when (file.extension.lowercase()) {
        "css" -> "css"
        "js" -> "js"
        "kt" -> "kotlin"
        "xml" -> "xml"
        else -> "html"
    }

    // ================= File list (drawer) & Project Management =================

    private fun updateDrawerProjectHeader() {
        val tvProjectTitle = findViewById<TextView>(R.id.tvProjectTitle)
        val badge = if (projectManager.getProjectType() == "compose") "🚀 [Compose]" else "🌐 [Web]"
        tvProjectTitle?.text = "$badge ${projectManager.currentProjectName}"
    }

    private fun setupFileList() {
        fileListAdapter = FileListAdapter(
            files = projectManager.listProjectFiles(),
            onFileClick = { file -> openFileInEditor(file); drawerLayout.closeDrawers() },
            onFileLongClick = { file -> showFileOptionsDialog(file); true }
        )
        fileListRecyclerView.layoutManager = LinearLayoutManager(this)
        fileListRecyclerView.adapter = fileListAdapter

        updateDrawerProjectHeader()

        findViewById<MaterialButton>(R.id.btnSwitchProject).setOnClickListener {
            showProjectManagerDialog()
        }
        findViewById<MaterialButton>(R.id.btnOpenZip).setOnClickListener {
            openZipLauncher.launch("*/*")
        }
        findViewById<MaterialButton>(R.id.btnOpenFiles).setOnClickListener {
            openFilesLauncher.launch("*/*")
        }
        findViewById<MaterialButton>(R.id.btnNewFile).setOnClickListener {
            promptNewFileName()
        }
        findViewById<MaterialButton>(R.id.btnNewFolder).setOnClickListener {
            promptNewFolderName()
        }
        findViewById<MaterialButton>(R.id.btnExportDownloads).setOnClickListener {
            exportProjectToDownloadsFolder()
        }
    }

    private fun refreshFileList() {
        updateDrawerProjectHeader()
        fileListAdapter.updateFiles(
            projectManager.listProjectFiles(),
            projectManager.projectRoot,
            currentAppMode == "light"
        )
    }

    private fun showFileOptionsDialog(file: File) {
        val options = arrayOf("Open", "Rename", "Delete")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { openFileInEditor(file); drawerLayout.closeDrawers() }
                    1 -> promptRename(file)
                    2 -> confirmDelete(file)
                }
            }
            .show()
    }

    private fun promptNewFileName() {
        val input = EditText(this)
        input.hint = "e.g. about.html, style.css, script.js"
        AlertDialog.Builder(this)
            .setTitle("New file name")
            .setView(wrapInputPadding(input))
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val file = projectManager.createNewFile(name)
                    refreshFileList()
                    openFileInEditor(file)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptNewFolderName() {
        val input = EditText(this)
        input.hint = "e.g. images, css, components"
        AlertDialog.Builder(this)
            .setTitle("New folder in project")
            .setView(wrapInputPadding(input))
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    projectManager.createSubfolder(name)
                    refreshFileList()
                    toast("Created folder: $name")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptRename(file: File) {
        val input = EditText(this)
        input.setText(file.name)
        AlertDialog.Builder(this)
            .setTitle("Rename file")
            .setView(wrapInputPadding(input))
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val renamed = projectManager.renameFile(file, newName)
                    tabAdapter.updateRenamedFile(file, renamed)
                    if (currentOpenFile?.absolutePath == file.absolutePath) {
                        currentOpenFile = renamed
                    }
                    refreshFileList()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${file.name}?")
            .setMessage("This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                projectManager.deleteFile(file)
                closeTab(file)
                refreshFileList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun renameCurrentFile() {
        currentOpenFile?.let { promptRename(it) } ?: toast("Open a file first")
    }

    private fun deleteCurrentFile() {
        currentOpenFile?.let { confirmDelete(it) } ?: toast("Open a file first")
    }

    private fun wrapInputPadding(input: EditText): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        val padding = (16 * resources.displayMetrics.density).toInt()
        layout.setPadding(padding, padding / 2, padding, 0)
        layout.addView(input)
        return layout
    }

    // ================= Project Switcher & Management =================

    private fun showProjectManagerDialog() {
        val projects = projectManager.listAllProjects()
        val current = projectManager.currentProjectName
        val displayItems = projects.map { if (it == current) "⭐ $it (Active)" else "📁 $it" }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Manage Projects (${projects.size})")
            .setItems(displayItems) { _, which ->
                val selected = projects[which]
                if (selected != current) {
                    saveCurrentFileSilently {
                        projectManager.switchProject(selected)
                        currentOpenFile = null
                        tabAdapter.clearTabs()
                        updateEmptyTabsState()
                        refreshFileList()
                        val main = projectManager.findMainHtmlFile() ?: projectManager.listProjectFiles().firstOrNull()
                        if (main != null) {
                            openFileInEditor(main)
                        } else {
                            loadContentIntoEditor("", "html")
                        }
                        updateDrawerProjectHeader()
                        updateBottomActionButton()
                        setupQuickInsertBar()
                        toast("Switched to project: $selected")
                    }
                }
            }
            .setPositiveButton("➕ New Project") { _, _ ->
                promptNewProjectName()
            }
            .setNeutralButton("Options") { _, _ ->
                showProjectOptionsMenu()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showProjectOptionsMenu() {
        val options = arrayOf("Delete a Project", "Rename Current Project")
        AlertDialog.Builder(this)
            .setTitle("Project Options")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> promptDeleteProject()
                    1 -> promptRenameCurrentProject()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptDeleteProject() {
        val projects = projectManager.listAllProjects()
        if (projects.size <= 1) {
            toast("Cannot delete the only remaining project.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Select Project to Delete")
            .setItems(projects.toTypedArray()) { _, which ->
                val proj = projects[which]
                AlertDialog.Builder(this)
                    .setTitle("Delete '$proj'?")
                    .setMessage("All files inside this project will be permanently deleted.")
                    .setPositiveButton("Delete Permanently") { _, _ ->
                        projectManager.deleteProject(proj)
                        refreshFileList()
                        val main = projectManager.findMainHtmlFile() ?: projectManager.listProjectFiles().firstOrNull()
                        if (main != null) openFileInEditor(main) else loadContentIntoEditor("", "html")
                        toast("Deleted project: $proj")
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptRenameCurrentProject() {
        val input = EditText(this)
        input.setText(projectManager.currentProjectName)
        AlertDialog.Builder(this)
            .setTitle("Rename Project")
            .setView(wrapInputPadding(input))
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val success = projectManager.renameProject(projectManager.currentProjectName, newName)
                    if (success) {
                        refreshFileList()
                        toast("Project renamed to: $newName")
                    } else {
                        toast("Failed to rename project (name may already exist)")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptNewProjectName() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, (12 * resources.displayMetrics.density).toInt(), pad, (8 * resources.displayMetrics.density).toInt())
        }

        val nameInput = EditText(this).apply {
            hint = "e.g. MyComposeApp, PortfolioApp"
            setSingleLine(true)
        }
        container.addView(nameInput)

        val isLight = currentAppMode == "light"
        val textColor = if (isLight) Color.parseColor("#1F2328") else Color.WHITE

        val typeLabel = TextView(this).apply {
            text = "Select Project Type:"
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(textColor)
            setPadding(0, (14 * resources.displayMetrics.density).toInt(), 0, (6 * resources.displayMetrics.density).toInt())
        }
        container.addView(typeLabel)

        val radioGroup = RadioGroup(this)
        val rbHtml = RadioButton(this).apply {
            id = View.generateViewId()
            text = "🌐 Web App (HTML5, CSS3, JavaScript)"
            setTextColor(textColor)
            textSize = 13f
        }
        val rbCompose = RadioButton(this).apply {
            id = View.generateViewId()
            text = "🚀 Native Jetpack Compose App (Kotlin)"
            setTextColor(textColor)
            textSize = 13f
        }
        radioGroup.addView(rbHtml)
        radioGroup.addView(rbCompose)
        radioGroup.check(rbHtml.id)

        rbHtml.setOnClickListener {
            radioGroup.check(rbHtml.id)
        }
        rbCompose.setOnClickListener {
            radioGroup.check(rbCompose.id)
        }
        container.addView(radioGroup)

        AlertDialog.Builder(this)
            .setTitle("Create New Project")
            .setView(container)
            .setPositiveButton("Create") { _, _ ->
                val name = nameInput.text.toString().trim()
                val selectedType = if (radioGroup.checkedRadioButtonId == rbCompose.id) "compose" else "html"
                if (name.isNotEmpty()) {
                    saveCurrentFileSilently {
                        projectManager.createNewProject(name, projectType = selectedType, withBoilerplate = true)
                        currentOpenFile = null
                        tabAdapter.clearTabs()
                        updateEmptyTabsState()
                        refreshFileList()
                        val main = projectManager.findMainHtmlFile()
                        if (main != null) {
                            openFileInEditor(main)
                        }
                        updateBottomActionButton()
                        setupQuickInsertBar()
                        toast("Created & switched to $selectedType project: $name")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportProjectToDownloadsFolder() {
        saveCurrentFileSilently {
            try {
                val targetDir = projectManager.exportProjectToDownloads()
                AlertDialog.Builder(this)
                    .setTitle("✅ Project Exported to Phone!")
                    .setMessage("Your entire project folder has been saved to your device's Downloads directory:\n\n📁 ${targetDir.absolutePath}\n\nYou can access, copy, or browse these files with any File Manager app on your phone.")
                    .setPositiveButton("OK", null)
                    .show()
            } catch (e: Exception) {
                toast("Export failed: ${e.message}")
            }
        }
    }

    // ================= Standalone APK Builder =================

    private fun promptBuildStandaloneApk() {
        saveCurrentFileSilently {
            val isCompose = projectManager.getProjectType() == "compose"
            val targetFile = if (isCompose) {
                currentOpenFile ?: File(projectManager.projectRoot, "MainActivity.kt")
            } else {
                resolvePreviewTarget()
            }
            if (targetFile == null) {
                toast(if (isCompose) "No entry file found in Compose project to build APK" else "No HTML file found in project to build APK")
                return@saveCurrentFileSilently
            }
            standaloneApkBuilder.showBuildDialog(targetFile, projectManager)
        }
    }

    // ================= Save As: Phone Storage (SAF) & Inside Project =================

    private fun saveAsToPhoneStorage() {
        val current = currentOpenFile
        val defaultName = current?.name ?: "index.html"
        getEditorContent { content ->
            pendingSaveAsContent = content
            saveAsDocumentLauncher.launch(defaultName)
        }
    }

    private fun saveAsInProject() {
        val current = currentOpenFile
        if (current == null) {
            toast("No file open to save as")
            return
        }

        val dotIndex = current.name.lastIndexOf('.')
        val suggestedName = if (dotIndex != -1) {
            val base = current.name.substring(0, dotIndex)
            val ext = current.name.substring(dotIndex)
            "${base}_copy$ext"
        } else {
            "${current.name}_copy"
        }

        val input = EditText(this)
        input.setText(suggestedName)
        input.setSelection(suggestedName.length)

        AlertDialog.Builder(this)
            .setTitle("Save As (In Project)")
            .setView(wrapInputPadding(input))
            .setPositiveButton("Save") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    getEditorContent { content ->
                        val newFile = projectManager.createNewFile(newName)
                        newFile.writeText(content)
                        refreshFileList()
                        openFileInEditor(newFile)
                        toast("✅ Saved copy inside project: $newName")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun copyAllContent() {
        if (currentOpenFile == null) {
            toast("No file open to copy")
            return
        }
        getEditorContent { content ->
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Editor Code", content)
            clipboard.setPrimaryClip(clip)
            toast("Copied all to clipboard (${content.length} chars)")
        }
    }

    private fun deleteAllContent() {
        if (currentOpenFile == null) {
            toast("No file open")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Delete All Content?")
            .setMessage("Are you sure you want to delete all text in this file? This cannot be undone.")
            .setPositiveButton("Delete All") { _, _ ->
                editorWebView.evaluateJavascript("clearContent()", null)
                currentOpenFile?.writeText("")
                toast("All content cleared")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ================= Tab & Editor Switching / Saving =================


    private fun openFileInEditor(file: File, skipAutoSave: Boolean = false) {
        val proceed = {
            currentOpenFile = file
            tabAdapter.addOrSelectTab(file)
            updateEmptyTabsState()
            val position = tabAdapter.getOpenFiles().indexOfFirst { it.absolutePath == file.absolutePath }
            if (position != -1) {
                tabRecyclerView.smoothScrollToPosition(position)
            }
            val content = if (file.exists()) file.readText() else ""
            val lang = langForFile(file)
            if (editorReady) {
                loadContentIntoEditor(content, lang)
            } else {
                pendingContentToLoad = Pair(content, lang)
            }
            updateBottomActionButton()
            setupQuickInsertBar()
        }

        if (skipAutoSave) {
            proceed()
        } else {
            saveCurrentFileSilently {
                proceed()
            }
        }
    }

    private fun switchToFile(file: File) {
        saveCurrentFileSilently {
            currentOpenFile = file
            tabAdapter.setActiveFile(file)
            val content = if (file.exists()) file.readText() else ""
            val lang = langForFile(file)
            if (editorReady) {
                loadContentIntoEditor(content, lang)
            } else {
                pendingContentToLoad = Pair(content, lang)
            }
            updateBottomActionButton()
            setupQuickInsertBar()
        }
    }

    private fun closeTab(file: File) {
        val isClosingActive = currentOpenFile?.absolutePath == file.absolutePath
        if (isClosingActive) {
            saveCurrentFileSilently {
                val nextActive = tabAdapter.removeTab(file)
                updateEmptyTabsState()
                if (nextActive != null) {
                    currentOpenFile = nextActive
                    val content = if (nextActive.exists()) nextActive.readText() else ""
                    val lang = langForFile(nextActive)
                    if (editorReady) {
                        loadContentIntoEditor(content, lang)
                    } else {
                        pendingContentToLoad = Pair(content, lang)
                    }
                } else {
                    currentOpenFile = null
                    if (editorReady) {
                        loadContentIntoEditor("", "html")
                    }
                }
            }
        } else {
            tabAdapter.removeTab(file)
            updateEmptyTabsState()
        }
    }

    private fun saveCurrentFileSilently(afterSaved: (() -> Unit)? = null) {
        val file = currentOpenFile
        if (file == null) {
            afterSaved?.invoke()
            return
        }
        getEditorContent { content ->
            file.writeText(content)
            afterSaved?.invoke()
        }
    }

    private fun updateBottomActionButton() {
        val btnAction = findViewById<MaterialButton>(R.id.btnBottomAction) ?: return
        val isCompose = currentOpenFile?.extension.equals("kt", true) || projectManager.getProjectType() == "compose"
        btnAction.text = if (isCompose) "🚀 Build" else "▶ Run"
    }

    private fun setupBottomButtons() {
        findViewById<Button>(R.id.btnBottomFiles).setOnClickListener {
            drawerLayout.openDrawer(androidx.core.view.GravityCompat.START)
        }

        findViewById<Button>(R.id.btnBottomSave).setOnClickListener {
            val file = currentOpenFile
            if (file == null) {
                toast("No file open to save")
            } else {
                getEditorContent { content ->
                    file.writeText(content)
                    val relPath = try {
                        file.relativeTo(projectManager.projectRoot).path.replace("\\", "/")
                    } catch (_: Exception) {
                        file.name
                    }
                    toast("✅ Saved: ${projectManager.currentProjectName}/$relPath")
                }
            }
        }

        findViewById<Button>(R.id.btnBottomTheme).setOnClickListener {
            showThemeDialog()
        }

        val btnAction = findViewById<MaterialButton>(R.id.btnBottomAction)
        updateBottomActionButton()

        btnAction.setOnClickListener {
            val isCompose = currentOpenFile?.extension.equals("kt", true) || projectManager.getProjectType() == "compose"
            if (isCompose) {
                promptBuildStandaloneApk()
            } else {
                previewInApp()
            }
        }

        btnAction.setOnLongClickListener {
            val isCompose = currentOpenFile?.extension.equals("kt", true) || projectManager.getProjectType() == "compose"
            if (isCompose) {
                promptBuildStandaloneApk()
            } else {
                previewInBrowser()
            }
            true
        }
    }

    private fun setupQuickInsertBar() {
        val bar = findViewById<LinearLayout>(R.id.quickInsertBar) ?: return
        bar.removeAllViews()

        val isLight = currentAppMode == "light"
        val strokeColor = if (isLight) Color.parseColor("#CCCCCC") else ContextCompat.getColor(this, R.color.divider)
        val btnTextColor = if (isLight) Color.parseColor("#1F2328") else ContextCompat.getColor(this, R.color.white)

        val isXml = currentOpenFile?.extension.equals("xml", true)
        val isCompose = currentOpenFile?.extension.equals("kt", true) || (!isXml && projectManager.getProjectType() == "compose")

        val snippets = when {
            isXml -> listOf(
                "<uses-permission android:name=\"android.permission.INTERNET\" />" to "Internet",
                "<uses-permission android:name=\"android.permission.CAMERA\" />" to "Camera",
                "<uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\" />" to "Location",
                "<uses-permission android:name=\"android.permission.RECORD_AUDIO\" />" to "Audio",
                "<uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\" />" to "Storage",
                "<activity\n    android:name=\".MainActivity\"\n    android:exported=\"true\">\n</activity>" to "<activity>",
                "<intent-filter>\n    <action android:name=\"android.intent.action.MAIN\" />\n    <category android:name=\"android.intent.category.LAUNCHER\" />\n</intent-filter>" to "Launcher",
                "<string name=\"app_name\">My App</string>" to "<string>",
                "<color name=\"primary\">#6200EE</color>" to "<color>",
                "<!--  -->" to "<!-- -->",
                "< >" to "< >",
                "</ >" to "</ >",
                "\"\"" to "\" \"",
                "=" to "="
            )
            isCompose -> listOf(
                "@Composable\nfun MyScreen() {\n  \n}" to "@Composable",
                "Column(\n  modifier = Modifier.fillMaxWidth()\n) {\n  \n}" to "Column",
                "Row(\n  modifier = Modifier.fillMaxWidth()\n) {\n  \n}" to "Row",
                "Text(text = \"Hello\")" to "Text",
                "Button(onClick = { /* TODO */ }) {\n  Text(\"Click\")\n}" to "Button",
                "Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {\n  \n}" to "Card",
                "Box(modifier = Modifier.fillMaxSize()) {\n  \n}" to "Box",
                "Spacer(modifier = Modifier.height(16.dp))" to "Spacer",
                "var count by remember { mutableStateOf(0) }" to "remember",
                "Modifier.fillMaxWidth()" to "Modifier",
                "Modifier.padding(16.dp)" to "padding",
                "Alignment.CenterHorizontally" to "Alignment",
                "OutlinedTextField(value = text, onValueChange = { text = it })" to "TextField",
                "{ }" to "{ }",
                "( )" to "( )",
                "= " to "=",
                ".dp" to ".dp"
            )
            else -> listOf(
                "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <title>App</title>\n</head>\n<body>\n  \n</body>\n</html>" to "!DOCTYPE",
                "<div>\n  \n</div>" to "<div>",
                "<p></p>" to "<p>",
                "<h1></h1>" to "<h1>",
                "<h2></h2>" to "<h2>",
                "<button></button>" to "<button>",
                "<input type=\"text\" placeholder=\"\" />" to "<input>",
                "<a href=\"\"></a>" to "<a>",
                "<img src=\"\" alt=\"\" />" to "<img>",
                "<span></span>" to "<span>",
                "<style>\n  \n</style>" to "<style>",
                "<script>\n  \n</script>" to "<script>",
                "class=\"\"" to "class",
                "id=\"\"" to "id",
                "<!--  -->" to "<!-- -->",
                "{ }" to "{ }",
                "( )" to "( )",
                "[ ]" to "[ ]",
                "< >" to "< >",
                "\"\"" to "\" \"",
                " = " to "=",
                ";" to ";"
            )
        }

        for ((snippet, label) in snippets) {
            val btn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            btn.text = label
            btn.textSize = 11f
            btn.setTextColor(btnTextColor)
            btn.strokeColor = ColorStateList.valueOf(strokeColor)
            btn.setPadding(16, 0, 16, 0)
            btn.isAllCaps = false
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.marginEnd = 6
            btn.layoutParams = params
            btn.setOnClickListener {
                val escaped = org.json.JSONObject.quote(snippet)
                editorWebView.evaluateJavascript("insertAtCursor($escaped)", null)
            }
            bar.addView(btn)
        }
    }

    // ================= Preview =================

    private fun previewInApp() {
        saveCurrentFileSilently {
            val mainHtml = resolvePreviewTarget()
            if (mainHtml == null) {
                toast("No HTML file found in project")
                return@saveCurrentFileSilently
            }
            val intent = Intent(this, PreviewActivity::class.java)
            intent.putExtra(PreviewActivity.EXTRA_HTML_PATH, mainHtml.absolutePath)
            startActivity(intent)
        }
    }

    private fun previewInBrowser() {
        saveCurrentFileSilently {
            val mainHtml = resolvePreviewTarget()
            if (mainHtml == null) {
                toast("No HTML file found in project")
                return@saveCurrentFileSilently
            }
            try {
                val uri = FileProvider.getUriForFile(
                    this, "${packageName}.fileprovider", mainHtml
                )
                val intent = Intent(Intent.ACTION_VIEW)
                intent.setDataAndType(uri, "text/html")
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                toast("No browser app found to open the file")
            }
        }
    }

    /**
     * Decides which HTML file to preview: the currently open one if it's HTML,
     * otherwise the project's main/index.html.
     */
    private fun resolvePreviewTarget(): File? {
        val current = currentOpenFile
        if (current != null && (current.extension.equals("html", true) || current.extension.equals("htm", true))) {
            return current
        }
        return projectManager.findMainHtmlFile()
    }

    // ================= Import: ZIP & multi-file =================

    private fun handleZipImport(uri: Uri) {
        val fileName = queryFileName(uri) ?: "ImportedProject.zip"
        val rawProjectName = fileName.substringBeforeLast(".", fileName)

        saveCurrentFileSilently {
            try {
                var importedDir: File? = null
                contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input).use { zis ->
                        importedDir = projectManager.importZipAsProject(rawProjectName, zis)
                    }
                }

                if (importedDir != null) {
                    currentOpenFile = null
                    tabAdapter.clearTabs()
                    updateEmptyTabsState()
                    refreshFileList()

                    val main = projectManager.findMainHtmlFile() ?: projectManager.listProjectFiles().firstOrNull()
                    if (main != null) {
                        openFileInEditor(main)
                    } else {
                        loadContentIntoEditor("", "html")
                    }
                    updateDrawerProjectHeader()
                    updateBottomActionButton()
                    setupQuickInsertBar()

                    val pName = projectManager.currentProjectName
                    val pType = projectManager.getProjectType()
                    toast("🎉 '$pName' ($pType) imported as a separate project!")
                } else {
                    toast("Could not read ZIP file")
                }
            } catch (e: Exception) {
                toast("Failed to import ZIP: ${e.message}")
            }
        }
    }

    private fun handleMultiFileImport(uris: List<Uri>) {
        try {
            for (uri in uris) {
                val name = queryFileName(uri) ?: "file_${System.currentTimeMillis()}"
                projectManager.importSingleFile(name) {
                    contentResolver.openInputStream(uri) ?: throw Exception("Cannot open $uri")
                }
            }
            refreshFileList()
            val main = projectManager.findMainHtmlFile()
            if (main != null) {
                openFileInEditor(main)
            }
            toast("${uris.size} file(s) imported")
        } catch (e: Exception) {
            toast("Failed to import files: ${e.message}")
        }
    }

    private fun queryFileName(uri: Uri): String? {
        var name: String? = null
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && nameIndex >= 0) {
                name = it.getString(nameIndex)
            }
        }
        return name
    }

    // ================= Export =================

    private fun exportProjectZip() {
        saveCurrentFileSilently {
            try {
                val exportsDir = File(cacheDir, "exports").apply { mkdirs() }
                val zipFile = File(exportsDir, "project_export.zip")
                projectManager.exportProjectAsZip(zipFile)
                val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", zipFile)
                val intent = Intent(Intent.ACTION_SEND)
                intent.type = "application/zip"
                intent.putExtra(Intent.EXTRA_STREAM, uri)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(intent, "Share project ZIP"))
            } catch (e: Exception) {
                toast("Export failed: ${e.message}")
            }
        }
    }

    // ================= Utils =================

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ================= App Mode & Code Box Color Themes =================

    private fun loadThemePreferences() {
        val prefs = getSharedPreferences("html_editor_prefs", Context.MODE_PRIVATE)
        currentAppMode = prefs.getString("app_mode", "dark") ?: "dark"
        currentEditorTheme = prefs.getString("editor_theme", "dark") ?: "dark"
    }

    private fun saveThemePreferences(appMode: String, editorTheme: String) {
        val prefs = getSharedPreferences("html_editor_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("app_mode", appMode)
            .putString("editor_theme", editorTheme)
            .apply()
        currentAppMode = appMode
        currentEditorTheme = editorTheme
    }

    private fun applyAppTheme(isLight: Boolean) {
        val topToolbar = findViewById<MaterialToolbar>(R.id.topToolbar)
        val tabBarContainer = findViewById<FrameLayout>(R.id.tabBarContainer)
        val quickInsertScroll = findViewById<View>(R.id.quickInsertScrollView)
        val bottomBar = findViewById<LinearLayout>(R.id.bottomActionBar)
        val drawerSidebar = findViewById<LinearLayout>(R.id.drawerSidebarLayout)
        val drawerHeader = findViewById<LinearLayout>(R.id.drawerHeaderCard)
        val tvProjectTitle = findViewById<TextView>(R.id.tvProjectTitle)
        val emptyText = findViewById<TextView>(R.id.emptyTabsText)

        val btnNewFolder = findViewById<MaterialButton>(R.id.btnNewFolder)
        val btnOpenZip = findViewById<MaterialButton>(R.id.btnOpenZip)
        val btnOpenFiles = findViewById<MaterialButton>(R.id.btnOpenFiles)
        val btnExportDownloads = findViewById<MaterialButton>(R.id.btnExportDownloads)

        if (isLight) {
            topToolbar?.setBackgroundColor(Color.parseColor("#FFFFFF"))
            topToolbar?.setTitleTextColor(Color.parseColor("#1F2328"))
            topToolbar?.navigationIcon?.setTint(Color.parseColor("#1F2328"))
            topToolbar?.overflowIcon?.setTint(Color.parseColor("#1F2328"))

            tabBarContainer?.setBackgroundColor(Color.parseColor("#E1E4E8"))
            emptyText?.setTextColor(Color.parseColor("#57606A"))

            quickInsertScroll?.setBackgroundColor(Color.parseColor("#F6F8FA"))
            bottomBar?.setBackgroundColor(Color.parseColor("#FFFFFF"))
            drawerSidebar?.setBackgroundColor(Color.parseColor("#FFFFFF"))
            drawerHeader?.setBackgroundColor(Color.parseColor("#E8ECEF"))

            tvProjectTitle?.setTextColor(Color.parseColor("#1F2328"))
            btnNewFolder?.setTextColor(Color.parseColor("#1F2328"))
            btnExportDownloads?.setTextColor(Color.parseColor("#1F2328"))

            btnOpenZip?.setTextColor(Color.parseColor("#1F2328"))
            btnOpenZip?.strokeColor = ColorStateList.valueOf(Color.parseColor("#D0D7DE"))
            btnOpenFiles?.setTextColor(Color.parseColor("#1F2328"))
            btnOpenFiles?.strokeColor = ColorStateList.valueOf(Color.parseColor("#D0D7DE"))

            findViewById<Button>(R.id.btnBottomFiles)?.setTextColor(Color.parseColor("#1F2328"))
            findViewById<Button>(R.id.btnBottomSave)?.setTextColor(Color.parseColor("#1F2328"))
            findViewById<Button>(R.id.btnBottomTheme)?.setTextColor(Color.parseColor("#1F2328"))
        } else {
            topToolbar?.setBackgroundColor(ContextCompat.getColor(this, R.color.toolbar_bg))
            topToolbar?.setTitleTextColor(ContextCompat.getColor(this, R.color.white))
            topToolbar?.navigationIcon?.setTint(ContextCompat.getColor(this, R.color.white))
            topToolbar?.overflowIcon?.setTint(ContextCompat.getColor(this, R.color.white))

            tabBarContainer?.setBackgroundColor(ContextCompat.getColor(this, R.color.tab_bar_bg))
            emptyText?.setTextColor(ContextCompat.getColor(this, R.color.tab_inactive_text))

            quickInsertScroll?.setBackgroundColor(ContextCompat.getColor(this, R.color.toolbar_bg))
            bottomBar?.setBackgroundColor(ContextCompat.getColor(this, R.color.toolbar_bg))
            drawerSidebar?.setBackgroundColor(ContextCompat.getColor(this, R.color.toolbar_bg))
            drawerHeader?.setBackgroundColor(Color.parseColor("#121212"))

            tvProjectTitle?.setTextColor(Color.parseColor("#FFFFFF"))
            btnNewFolder?.setTextColor(Color.parseColor("#FFFFFF"))
            btnExportDownloads?.setTextColor(Color.parseColor("#FFFFFF"))

            btnOpenZip?.setTextColor(Color.parseColor("#FFFFFF"))
            btnOpenZip?.strokeColor = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.divider))
            btnOpenFiles?.setTextColor(Color.parseColor("#FFFFFF"))
            btnOpenFiles?.strokeColor = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.divider))

            findViewById<Button>(R.id.btnBottomFiles)?.setTextColor(ContextCompat.getColor(this, R.color.white))
            findViewById<Button>(R.id.btnBottomSave)?.setTextColor(ContextCompat.getColor(this, R.color.white))
            findViewById<Button>(R.id.btnBottomTheme)?.setTextColor(ContextCompat.getColor(this, R.color.white))
        }

        if (::fileListAdapter.isInitialized) {
            fileListAdapter.setTheme(isLight)
        }
        setupQuickInsertBar()
    }

    private fun applyEditorTheme(theme: String) {
        currentEditorTheme = theme
        if (editorReady) {
            editorWebView.evaluateJavascript("setEditorTheme('$theme')", null)
        }
    }

    private fun showThemeDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_theme_selector, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        val rbAppDark = dialogView.findViewById<RadioButton>(R.id.rbAppDark)
        val rbAppLight = dialogView.findViewById<RadioButton>(R.id.rbAppLight)

        val rbEditorDark = dialogView.findViewById<RadioButton>(R.id.rbEditorDark)
        val rbEditorLight = dialogView.findViewById<RadioButton>(R.id.rbEditorLight)
        val rbEditorMidnight = dialogView.findViewById<RadioButton>(R.id.rbEditorMidnight)
        val rbEditorMonokai = dialogView.findViewById<RadioButton>(R.id.rbEditorMonokai)
        val rbEditorOled = dialogView.findViewById<RadioButton>(R.id.rbEditorOled)

        // Pre-select current App Mode
        if (currentAppMode == "light") {
            rbAppLight.isChecked = true
        } else {
            rbAppDark.isChecked = true
        }

        // Pre-select current Editor Code Box Theme
        when (currentEditorTheme) {
            "light" -> rbEditorLight.isChecked = true
            "midnight" -> rbEditorMidnight.isChecked = true
            "monokai" -> rbEditorMonokai.isChecked = true
            "oled" -> rbEditorOled.isChecked = true
            else -> rbEditorDark.isChecked = true
        }

        dialogView.findViewById<Button>(R.id.themeBtnCancel).setOnClickListener {
            dialog.dismiss()
        }

        dialogView.findViewById<Button>(R.id.themeBtnApply).setOnClickListener {
            val selectedAppMode = if (rbAppLight.isChecked) "light" else "dark"
            val selectedEditorTheme = when {
                rbEditorLight.isChecked -> "light"
                rbEditorMidnight.isChecked -> "midnight"
                rbEditorMonokai.isChecked -> "monokai"
                rbEditorOled.isChecked -> "oled"
                else -> "dark"
            }

            saveThemePreferences(selectedAppMode, selectedEditorTheme)
            applyAppTheme(selectedAppMode == "light")
            applyEditorTheme(selectedEditorTheme)

            dialog.dismiss()
            toast("Theme applied: App (${selectedAppMode.replaceFirstChar { it.uppercase() }}), Code Box ($selectedEditorTheme)")
        }

        dialog.show()
    }


    override fun onPause() {
        super.onPause()
        // Auto-save on pause so nothing is lost if the app is backgrounded
        saveCurrentFileSilently()
    }
}
