package com.example.htmleditor

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.concurrent.thread

class StandaloneApkBuilder(private val activity: AppCompatActivity) {

    private val prefs = activity.getSharedPreferences("github_builder_prefs", Context.MODE_PRIVATE)
    private val mainHandler = Handler(Looper.getMainLooper())

    var onPickIconRequested: (() -> Unit)? = null
    private var selectedIconBitmap: Bitmap? = null
    private var dialogIconPreview: ImageView? = null

    fun setPickedIcon(uri: Uri) {
        try {
            activity.contentResolver.openInputStream(uri)?.use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream)
                selectedIconBitmap = bitmap
                dialogIconPreview?.setImageBitmap(bitmap)
            }
        } catch (e: Exception) {
            Toast.makeText(activity, "Failed to load icon: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun getRepo(): String = prefs.getString("repo", "") ?: ""
    fun getToken(): String = prefs.getString("token", "") ?: ""

    fun saveGitHubConfig(repo: String, token: String) {
        prefs.edit().putString("repo", repo.trim()).putString("token", token.trim()).apply()
    }

    fun showSettingsDialog(onSaved: (() -> Unit)? = null) {
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_github_settings, null)
        val editRepo = view.findViewById<EditText>(R.id.settingsEditRepo)
        val editToken = view.findViewById<EditText>(R.id.settingsEditToken)

        editRepo.setText(getRepo())
        editToken.setText(getToken())

        val dialog = AlertDialog.Builder(activity)
            .setView(view)
            .create()

        view.findViewById<Button>(R.id.settingsBtnCancel).setOnClickListener {
            dialog.dismiss()
        }

        view.findViewById<MaterialButton>(R.id.settingsBtnSave).setOnClickListener {
            val repo = editRepo.text.toString().trim()
            val token = editToken.text.toString().trim()
            if (repo.isEmpty() || token.isEmpty()) {
                Toast.makeText(activity, "Please enter both repository and token", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            saveGitHubConfig(repo, token)
            Toast.makeText(activity, "GitHub settings saved!", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            onSaved?.invoke()
        }

        dialog.show()
    }

    fun showBuildDialog(htmlFile: File, projectRoot: File) {
        val repo = getRepo()
        val token = getToken()
        if (repo.isEmpty() || token.isEmpty()) {
            AlertDialog.Builder(activity)
                .setTitle("GitHub Setup Required")
                .setMessage("To compile standalone APKs via GitHub Actions, please connect your GitHub repository and token first.")
                .setPositiveButton("Configure Now") { _, _ ->
                    showSettingsDialog { showBuildDialog(htmlFile, projectRoot) }
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_build_standalone_apk, null)
        val editAppName = view.findViewById<EditText>(R.id.dialogEditAppName)
        val editPackageId = view.findViewById<EditText>(R.id.dialogEditPackageId)
        val btnPickIcon = view.findViewById<MaterialButton>(R.id.dialogBtnPickIcon)
        dialogIconPreview = view.findViewById(R.id.dialogAppIconPreview)
        val radioSplashDark = view.findViewById<RadioButton>(R.id.radioSplashDark)

        // Default name from file name
        val defaultName = htmlFile.nameWithoutExtension.replace('_', ' ').replace('-', ' ')
            .split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        editAppName.setText(defaultName)

        val cleanSlug = htmlFile.nameWithoutExtension.lowercase().replace(Regex("[^a-z0-9]"), "")
        editPackageId.setText("com.webapp.${if (cleanSlug.isNotEmpty()) cleanSlug else "app"}")

        // Check if project has an icon.png
        val projectIcon = File(projectRoot, "icon.png")
        if (projectIcon.exists()) {
            try {
                selectedIconBitmap = BitmapFactory.decodeFile(projectIcon.absolutePath)
                dialogIconPreview?.setImageBitmap(selectedIconBitmap)
            } catch (_: Exception) {}
        }

        val dialog = AlertDialog.Builder(activity)
            .setView(view)
            .create()

        btnPickIcon.setOnClickListener {
            onPickIconRequested?.invoke()
        }

        view.findViewById<Button>(R.id.dialogBtnCancel).setOnClickListener {
            dialog.dismiss()
        }

        view.findViewById<MaterialButton>(R.id.dialogBtnBuild).setOnClickListener {
            val appName = editAppName.text.toString().trim()
            val packageId = editPackageId.text.toString().trim()
            val splashColor = if (radioSplashDark.isChecked) "#1E1E1E" else "#FFFFFF"

            if (appName.isEmpty()) {
                Toast.makeText(activity, "Please enter an App Name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            dialog.dismiss()
            startBuildProcess(htmlFile, projectRoot, appName, packageId, splashColor, selectedIconBitmap)
        }

        dialog.show()
    }

    private fun startBuildProcess(
        htmlFile: File,
        projectRoot: File,
        appName: String,
        packageId: String,
        splashColor: String,
        iconBitmap: Bitmap?
    ) {
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_build_progress, null)
        val titleText = view.findViewById<TextView>(R.id.progressTitle)
        val subtitleText = view.findViewById<TextView>(R.id.progressSubtitle)
        val btnDismiss = view.findViewById<MaterialButton>(R.id.progressBtnDismiss)

        val progressDialog = AlertDialog.Builder(activity)
            .setView(view)
            .setCancelable(false)
            .create()

        btnDismiss.setOnClickListener {
            progressDialog.dismiss()
            Toast.makeText(activity, "Building in background. You will be notified when ready.", Toast.LENGTH_SHORT).show()
        }

        progressDialog.show()

        thread {
            try {
                // 1. Package HTML and icon
                updateProgress(titleText, subtitleText, "Packaging Web App", "Bundling HTML, CSS, and JS files...")
                val standaloneHtml = HtmlCombiner.buildStandaloneHtml(htmlFile, projectRoot)

                val iconBase64 = iconBitmap?.let { bitmap ->
                    val stream = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                    Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
                } ?: ""

                val payload = JSONObject().apply {
                    put("app_name", appName)
                    put("package_id", packageId)
                    put("splash_color", splashColor)
                    put("icon_base64", iconBase64)
                    put("html_content", standaloneHtml)
                }

                // 2. Check and Auto-Initialize GitHub Repository
                val client = GitHubApiClient(getRepo(), getToken())

                // If workflow is missing, automatically upload it from app assets!
                if (!client.checkWorkflowExists()) {
                    updateProgress(titleText, subtitleText, "Initializing Repository", "Setting up GitHub Actions workflow in your repository...")
                    val workflowBytes = try {
                        activity.assets.open("workflow/build-standalone-apk.yml").use { it.readBytes() }
                    } catch (e: Exception) {
                        null
                    }
                    if (workflowBytes != null) {
                        val uploaded = client.uploadFile(
                            ".github/workflows/build-standalone-apk.yml",
                            workflowBytes,
                            "Setup Standalone APK Builder Workflow"
                        )
                        if (!uploaded) {
                            throw Exception("Failed to setup workflow in repository. Please ensure your token has 'workflow' and 'repo' permissions.")
                        }
                    }
                }

                // If template is missing in an empty repository, upload the project template (82 KB)
                if (client.getFileSha("app/build.gradle") == null && client.getFileSha("build_payload/template.zip") == null) {
                    updateProgress(titleText, subtitleText, "Setting up Build Template", "Uploading Android app template to repository (80 KB)...")
                    val templateBytes = try {
                        activity.assets.open("template/project_template.zip").use { it.readBytes() }
                    } catch (e: Exception) {
                        null
                    }
                    if (templateBytes != null) {
                        client.uploadFile("build_payload/template.zip", templateBytes, "Add Standalone Project Template")
                    }
                }

                updateProgress(titleText, subtitleText, "Triggering GitHub Actions", "Uploading payload to cloud runner...")

                val uploaded = client.uploadBuildPayload(payload.toString())
                if (!uploaded) {
                    throw Exception("Failed to upload build payload to GitHub. Please check repository name and token permissions.")
                }

                // 3. Poll workflow status
                updateProgress(titleText, subtitleText, "Compiling Standalone APK", "GitHub Actions is compiling with Gradle...")

                var runId: Long? = null
                var attempt = 0
                val startTime = System.currentTimeMillis()

                // Wait for the new run to appear and finish (up to 4 minutes)
                while (attempt < 48) {
                    Thread.sleep(5000)
                    attempt++
                    val elapsedSeconds = (System.currentTimeMillis() - startTime) / 1000
                    val run = client.getLatestWorkflowRun()

                    if (run != null) {
                        runId = run.id
                        if (run.status == "completed") {
                            if (run.conclusion == "success") {
                                break
                            } else {
                                throw Exception("Build failed on GitHub Actions with status: ${run.conclusion}")
                            }
                        } else {
                            updateProgress(
                                titleText,
                                subtitleText,
                                "Compiling Standalone APK",
                                "Building Gradle project... (${elapsedSeconds}s elapsed)"
                            )
                        }
                    }
                }

                // 4. Fetch Release & Download APK
                updateProgress(titleText, subtitleText, "Downloading APK", "Fetching compiled APK from GitHub Release...")
                val apkDir = File(activity.getExternalFilesDir(null) ?: activity.cacheDir, "standalone_apks").apply { mkdirs() }
                val safeFileName = "${appName.replace(Regex("[^a-zA-Z0-9_-]"), "_")}.apk"
                val targetApk = File(apkDir, safeFileName)

                // Try downloading via release URL or fallback
                val downloadUrl = if (runId != null) client.getReleaseDownloadUrl(runId) else null
                val finalUrl = downloadUrl ?: "https://github.com/${getRepo()}/releases/download/standalone-build-$runId/standalone-app.apk"

                val downloaded = client.downloadApk(finalUrl, targetApk) { percent ->
                    updateProgress(titleText, subtitleText, "Downloading APK ($percent%)", "Saving $safeFileName...")
                }

                if (!downloaded || !targetApk.exists()) {
                    throw Exception("Could not download compiled APK from GitHub.")
                }

                // 5. Success -> Prompt Install
                mainHandler.post {
                    progressDialog.dismiss()
                    Toast.makeText(activity, "Build complete! Launching installer...", Toast.LENGTH_LONG).show()
                    launchPackageInstaller(targetApk)
                }

            } catch (e: Exception) {
                mainHandler.post {
                    progressDialog.dismiss()
                    AlertDialog.Builder(activity)
                        .setTitle("Build Error")
                        .setMessage(e.message ?: "Unknown error occurred during build")
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }
    }

    private fun updateProgress(titleView: TextView, subtitleView: TextView, title: String, subtitle: String) {
        mainHandler.post {
            titleView.text = title
            subtitleView.text = subtitle
        }
    }

    private fun launchPackageInstaller(apkFile: File) {
        try {
            val apkUri = FileProvider.getUriForFile(
                activity,
                "${activity.packageName}.fileprovider",
                apkFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(activity, "Cannot open installer: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
