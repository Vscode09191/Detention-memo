package com.example.htmleditor

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.CountDownTimer
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import kotlin.concurrent.thread

class StandaloneApkBuilder(private val activity: AppCompatActivity) {

    private val prefs = activity.getSharedPreferences("github_builder_prefs", Context.MODE_PRIVATE)
    private val mainHandler = Handler(Looper.getMainLooper())

    var onPickIconRequested: (() -> Unit)? = null
    private var selectedIconBitmap: Bitmap? = null
    private var dialogIconPreview: ImageView? = null
    private var dialogIconStatusView: TextView? = null

    fun setPickedIcon(uri: Uri) {
        try {
            activity.contentResolver.openInputStream(uri)?.use { stream ->
                val original = BitmapFactory.decodeStream(stream)
                if (original != null) {
                    val maxDim = 512
                    val width = original.width
                    val height = original.height
                    val scaled = if (width > maxDim || height > maxDim) {
                        val ratio = width.toFloat() / height.toFloat()
                        if (ratio > 1) {
                            Bitmap.createScaledBitmap(original, maxDim, (maxDim / ratio).toInt().coerceAtLeast(1), true)
                        } else {
                            Bitmap.createScaledBitmap(original, (maxDim * ratio).toInt().coerceAtLeast(1), maxDim, true)
                        }
                    } else {
                        original
                    }
                    selectedIconBitmap = scaled
                    dialogIconPreview?.setImageBitmap(scaled)
                    dialogIconStatusView?.text = "Selected from gallery"
                }
            }
        } catch (e: Exception) {
            Toast.makeText(activity, "Failed to load icon: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun getRepo(): String = prefs.getString("repo", "") ?: ""
    fun getToken(): String = prefs.getString("token", "") ?: ""

    fun saveGitHubConfig(repo: String, token: String) {
        prefs.edit().putString("repo", repo.trim()).putString("token", token.trim()).apply()
    }

    fun showSettingsDialog(onSaved: (() -> Unit)? = null) {
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_github_settings, null)
        val editRepo = view.findViewById<EditText>(R.id.settingsEditRepo)
        val editToken = view.findViewById<EditText>(R.id.settingsEditToken)

        editRepo.setText(getRepo())
        editToken.setText(getToken())

        val dialog = AlertDialog.Builder(activity)
            .setView(view)
            .setCancelable(true)
            .create()

        view.findViewById<Button>(R.id.settingsBtnCancel).setOnClickListener {
            dialog.dismiss()
        }

        view.findViewById<MaterialButton>(R.id.settingsBtnSave).setOnClickListener {
            val repo = editRepo.text.toString().trim()
            val token = editToken.text.toString().trim()

            if (repo.isEmpty() || !repo.contains("/")) {
                Toast.makeText(activity, "Please enter a valid repo (e.g. username/repo)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (token.isEmpty()) {
                Toast.makeText(activity, "Please enter your GitHub Personal Access Token", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            saveGitHubConfig(repo, token)
            dialog.dismiss()
            Toast.makeText(activity, "GitHub configuration saved!", Toast.LENGTH_SHORT).show()
            onSaved?.invoke()
        }

        dialog.show()
    }

    fun showBuildDialog(htmlFile: File, projectManager: ProjectManager) {
        val projectRoot = projectManager.projectRoot
        if (getRepo().isEmpty() || getToken().isEmpty()) {
            AlertDialog.Builder(activity)
                .setTitle("GitHub Setup Required")
                .setMessage("To compile standalone APKs with custom icons, permissions, and splash screens, you need a GitHub Repository & Token.\n\nWould you like to configure it now?")
                .setPositiveButton("Configure") { _, _ ->
                    showSettingsDialog {
                        showBuildDialog(htmlFile, projectManager)
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_build_standalone_apk, null)
        val textSubtitle = view.findViewById<TextView>(R.id.dialogSubTitle)
        val editAppName = view.findViewById<EditText>(R.id.dialogEditAppName)
        val editPackageId = view.findViewById<EditText>(R.id.dialogEditPackageId)
        val radioSplashDark = view.findViewById<RadioButton>(R.id.radioSplashDark)
        val btnPickIcon = view.findViewById<MaterialButton>(R.id.dialogBtnPickIcon)
        val sectionComposeInfo = view.findViewById<View>(R.id.dialogComposeInfoContainer)
        val sectionSplash = view.findViewById<View>(R.id.dialogSectionSplash)
        val sectionPermissions = view.findViewById<View>(R.id.dialogSectionPermissions)
        dialogIconPreview = view.findViewById(R.id.dialogAppIconPreview)
        dialogIconStatusView = view.findViewById(R.id.dialogIconStatus)

        val checkPermInternet = view.findViewById<android.widget.CheckBox>(R.id.checkPermInternet)
        val checkPermLocation = view.findViewById<android.widget.CheckBox>(R.id.checkPermLocation)
        val checkPermCamera = view.findViewById<android.widget.CheckBox>(R.id.checkPermCamera)
        val checkPermAudio = view.findViewById<android.widget.CheckBox>(R.id.checkPermAudio)
        val checkPermStorage = view.findViewById<android.widget.CheckBox>(R.id.checkPermStorage)

        val isCompose = projectManager.getProjectType() == "compose"

        // Adapt UI based on Compose vs HTML project
        if (isCompose) {
            textSubtitle?.text = "Compile your Jetpack Compose project into an installable Android APK"
            sectionComposeInfo?.visibility = View.VISIBLE
            sectionSplash?.visibility = View.GONE
            sectionPermissions?.visibility = View.GONE
        } else {
            textSubtitle?.text = "Convert your HTML project into an installable Android App"
            sectionComposeInfo?.visibility = View.GONE
            sectionSplash?.visibility = View.VISIBLE
            sectionPermissions?.visibility = View.VISIBLE
        }

        // Auto-detect App Name from strings.xml if present
        var detectedAppName = ""
        try {
            projectRoot.walkTopDown().maxDepth(6).filter { it.name.equals("strings.xml", ignoreCase = true) }.forEach { sf ->
                val m = Regex("""<string\s+name=["']app_name["']>([^<]+)</string>""").find(sf.readText())
                if (m != null) {
                    detectedAppName = m.groupValues[1].trim()
                    return@forEach
                }
            }
        } catch (_: Exception) {}

        val defaultName = if (detectedAppName.isNotEmpty()) detectedAppName else {
            projectManager.currentProjectName
                .replace("_", " ")
                .replace("-", " ")
                .split(" ")
                .joinToString(" ") { word -> word.replaceFirstChar { it.uppercase() } }
                .ifEmpty { if (isCompose) "My Compose App" else "My Web App" }
        }
        editAppName.setText(defaultName)

        // Auto-detect Package ID from AndroidManifest.xml or build.gradle if present
        var detectedPackageId = ""
        try {
            projectRoot.walkTopDown().maxDepth(6).forEach { f ->
                if (f.name.equals("AndroidManifest.xml", ignoreCase = true)) {
                    val m = Regex("""package\s*=\s*["']([^"']+)["']""").find(f.readText())
                    if (m != null) {
                        detectedPackageId = m.groupValues[1].trim()
                    }
                } else if (detectedPackageId.isEmpty() && (f.name.endsWith(".gradle") || f.name.endsWith(".gradle.kts"))) {
                    val m = Regex("""(?:applicationId|namespace)\s*[=\s]\s*["']([^"']+)["']""").find(f.readText())
                    if (m != null) {
                        detectedPackageId = m.groupValues[1].trim()
                    }
                }
            }
        } catch (_: Exception) {}

        val safePkg = defaultName.lowercase().replace(Regex("[^a-z0-9]"), "")
        editPackageId.setText(if (detectedPackageId.isNotEmpty()) detectedPackageId else "com.app.$safePkg")

        selectedIconBitmap = null

        val dialog = AlertDialog.Builder(activity)
            .setView(view)
            .setCancelable(true)
            .create()

        btnPickIcon.setOnClickListener {
            onPickIconRequested?.invoke()
        }

        // Auto-detect project icon from folder
        val projectIcon = findProjectIcon(projectRoot)
        if (projectIcon != null && projectIcon.exists()) {
            try {
                selectedIconBitmap = BitmapFactory.decodeFile(projectIcon.absolutePath)
                if (selectedIconBitmap != null) {
                    dialogIconPreview?.setImageBitmap(selectedIconBitmap)
                    dialogIconStatusView?.text = "Auto-detected: ${projectIcon.name}"
                }
            } catch (_: Exception) {}
        } else {
            dialogIconStatusView?.text = "Default Android icon"
        }

        view.findViewById<Button>(R.id.dialogBtnCancel).setOnClickListener {
            dialog.dismiss()
        }

        view.findViewById<MaterialButton>(R.id.dialogBtnBuild).setOnClickListener {
            val appName = editAppName.text.toString().trim()
            val packageId = editPackageId.text.toString().trim()
            val splashColor = if (radioSplashDark.isChecked) "#1E1E1E" else "#FFFFFF"

            val permissions = mutableListOf<String>()
            if (isCompose) {
                // Compose project permissions are natively defined in AndroidManifest.xml
            } else {
                if (checkPermInternet?.isChecked == true) permissions.add("INTERNET")
                if (checkPermLocation?.isChecked == true) permissions.add("LOCATION")
                if (checkPermCamera?.isChecked == true) permissions.add("CAMERA")
                if (checkPermAudio?.isChecked == true) permissions.add("AUDIO")
                if (checkPermStorage?.isChecked == true) permissions.add("STORAGE")
            }

            if (appName.isEmpty()) {
                Toast.makeText(activity, "Please enter an App Name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            dialog.dismiss()
            checkExistingOrStartBuild(htmlFile, projectManager, appName, packageId, splashColor, selectedIconBitmap, permissions)
        }

        dialog.show()
    }

    /**
     * Automatically discovers project icons from standard filenames (icon.png, logo.png)
     * or standard Android resource directories (res/mipmap*, res/drawable*).
     */
    private fun findProjectIcon(projectRoot: File): File? {
        val directNames = listOf("icon.png", "icon.webp", "logo.png", "logo.webp", "app_icon.png", "ic_launcher.png", "ic_launcher.webp")
        for (name in directNames) {
            val f = File(projectRoot, name)
            if (f.exists() && f.isFile) return f
        }

        var bestFile: File? = null
        var bestScore = 0
        try {
            projectRoot.walkTopDown().maxDepth(6).forEach { file ->
                if (file.isFile && (file.extension.equals("png", ignoreCase = true) || file.extension.equals("webp", ignoreCase = true))) {
                    val path = file.absolutePath.replace('\\', '/').lowercase()
                    var score = 0
                    if (path.contains("ic_launcher") || path.contains("ic_launcher_round")) score += 10
                    if (path.contains("xxxhdpi")) score += 6
                    else if (path.contains("xxhdpi")) score += 5
                    else if (path.contains("xhdpi")) score += 4
                    else if (path.contains("hdpi")) score += 3
                    else if (path.contains("mdpi")) score += 2
                    if (path.contains("mipmap")) score += 3
                    if (path.contains("drawable")) score += 2

                    if (score > bestScore) {
                        bestScore = score
                        bestFile = file
                    }
                }
            }
        } catch (_: Exception) {}
        return bestFile
    }

    /**
     * Resolves target APK file in safe app-specific external storage.
     * Guaranteed zero-permission write access on all Android versions (Android 5 to 15),
     * preventing EACCES (Permission denied) on modern Scoped Storage devices.
     */
    fun getTargetApkFile(appName: String): File {
        val safeFileName = "${appName.replace(Regex("[^a-zA-Z0-9_-]"), "_")}.apk"
        val appDownloads = File(activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: activity.filesDir, "HTML_APK_Builds")
        if (!appDownloads.exists()) {
            appDownloads.mkdirs()
        }
        return File(appDownloads, safeFileName)
    }

    /**
     * Copies the compiled APK to the device's public Downloads directory
     * via MediaStore (API 29+) or public directory (legacy), so it is visible in the Files app.
     */
    private fun exportToPublicDownloads(apkFile: File, appName: String) {
        if (!apkFile.exists() || apkFile.length() == 0L) return
        val safeName = "${appName.replace(Regex("[^a-zA-Z0-9_-]"), "_")}.apk"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = activity.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HTML_APK_Builds")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        apkFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                }
            } else {
                val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(publicDownloads, "HTML_APK_Builds")
                if (targetDir.mkdirs() || targetDir.exists()) {
                    val publicFile = File(targetDir, safeName)
                    apkFile.copyTo(publicFile, overwrite = true)
                    notifyMediaScanner(publicFile)
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Computes a unique fingerprint for this exact app code, assets, and metadata.
     */
    private fun computeFingerprint(
        appName: String,
        packageId: String,
        splashColor: String,
        htmlContent: String,
        iconBase64: String,
        permissions: List<String>,
        projectZipBase64: String,
        projectType: String = "html"
    ): String {
        val raw = "$appName|$packageId|$splashColor|$htmlContent|$iconBase64|${permissions.joinToString(",")}|$projectZipBase64|$projectType"
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(raw.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }.take(16)
    }

    /**
     * Level 1 Check: Checks if identical APK already exists in Downloads before doing anything.
     */
    private fun checkExistingOrStartBuild(
        htmlFile: File,
        projectManager: ProjectManager,
        appName: String,
        packageId: String,
        splashColor: String,
        iconBitmap: Bitmap?,
        permissions: List<String>
    ) {
        val projectRoot = projectManager.projectRoot
        val projectType = projectManager.getProjectType()
        val standaloneHtml = if (projectType == "compose") "" else HtmlCombiner.buildStandaloneHtml(htmlFile, projectRoot)
        val iconBase64 = iconBitmap?.let { bitmap ->
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
        } ?: ""

        val projectZipBase64 = projectManager.getProjectZipBase64()
        val entryFile = try {
            htmlFile.relativeTo(projectRoot).path.replace("\\", "/")
        } catch (_: Exception) {
            if (projectType == "compose") "MainActivity.kt" else "index.html"
        }

        val fingerprint = computeFingerprint(appName, packageId, splashColor, standaloneHtml, iconBase64, permissions, projectZipBase64, projectType)
        val targetApk = getTargetApkFile(appName)
        val savedFp = prefs.getString("fp_${targetApk.name}", null)

        // Level 1: Same APK exists in phone's Download folder with identical fingerprint!
        if (targetApk.exists() && targetApk.length() > 500000L && savedFp == fingerprint) {
            val sizeMb = String.format("%.1f", targetApk.length() / (1024.0 * 1024.0))
            AlertDialog.Builder(activity)
                .setTitle("⚡ APK Pehle Se Maujood Hai!")
                .setMessage("Is project ka bilkul same APK aapke Download folder mein pehle se bana hua hai:\n\n📁 Download/HTML_APK_Builds/${targetApk.name} ($sizeMb MB)\n\nPermissions aur code mein koi naya change nahi hua hai. Aap ise turant install kar sakte hain ya cloud par dubara build kar sakte hain.")
                .setPositiveButton("⚡ Install Now (Instant)") { _, _ ->
                    notifyMediaScanner(targetApk)
                    launchPackageInstaller(targetApk)
                }
                .setNegativeButton("🔄 Rebuild on Cloud") { _, _ ->
                    startBuildProcess(appName, packageId, splashColor, iconBase64, standaloneHtml, projectZipBase64, entryFile, permissions, fingerprint, targetApk, projectType)
                }
                .setNeutralButton("Cancel", null)
                .show()
            return
        }

        // Proceed to build / cloud check
        startBuildProcess(appName, packageId, splashColor, iconBase64, standaloneHtml, projectZipBase64, entryFile, permissions, fingerprint, targetApk, projectType)
    }

    private fun startBuildProcess(
        appName: String,
        packageId: String,
        splashColor: String,
        iconBase64: String,
        standaloneHtml: String,
        projectZipBase64: String,
        entryFile: String,
        permissions: List<String>,
        fingerprint: String,
        targetApk: File,
        projectType: String = "html"
    ) {
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_build_progress, null)
        val titleText = view.findViewById<TextView>(R.id.progressTitle)
        val subtitleText = view.findViewById<TextView>(R.id.progressSubtitle)
        val btnDismiss = view.findViewById<MaterialButton>(R.id.progressBtnDismiss)
        val timerView = view.findViewById<TextView>(R.id.progressTimer)
        val timerLabel = view.findViewById<TextView>(R.id.timerLabel)

        // Reverse countdown timer: 5 mins (300s) for Jetpack Compose, 2 mins (120s) for HTML APK
        val isCompose = projectType.equals("compose", ignoreCase = true)
        val totalMillis = if (isCompose) 300_000L else 120_000L

        val initTotalSec = totalMillis / 1000
        val initMins = initTotalSec / 60
        val initSecs = initTotalSec % 60
        timerView?.text = String.format("%02d:%02d", initMins, initSecs)
        timerLabel?.text = if (isCompose) " (Compose ~5m)" else " (HTML ~2m)"

        val countDownTimer = object : CountDownTimer(totalMillis, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val totalSec = millisUntilFinished / 1000
                val mins = totalSec / 60
                val secs = totalSec % 60
                timerView?.text = String.format("%02d:%02d", mins, secs)
            }

            override fun onFinish() {
                timerView?.text = "00:00"
                timerLabel?.text = " (Finalizing...)"
            }
        }.start()

        val progressDialog = AlertDialog.Builder(activity)
            .setView(view)
            .setCancelable(false)
            .create()

        progressDialog.setOnDismissListener {
            countDownTimer.cancel()
        }

        btnDismiss.setOnClickListener {
            progressDialog.dismiss()
            Toast.makeText(activity, "Building in background. You will be notified when ready.", Toast.LENGTH_SHORT).show()
        }

        progressDialog.show()

        thread {
            try {
                val client = GitHubApiClient(getRepo(), getToken())

                // Level 2 Check: Check if GitHub Release already has this exact compiled version
                updateProgress(titleText, subtitleText, "Checking Existing Builds", "Checking if this version is already compiled on GitHub...")
                val cachedReleaseUrl = client.findReleaseByFingerprint(fingerprint)

                if (cachedReleaseUrl != null) {
                    updateProgress(titleText, subtitleText, "⚡ Pre-compiled APK Found!", "Downloading existing build directly from GitHub Release...")
                    val downloaded = client.downloadApk(cachedReleaseUrl, targetApk) { percent ->
                        updateProgress(titleText, subtitleText, "Downloading APK ($percent%)", "Saving to Download/HTML_APK_Builds/${targetApk.name}...")
                    }
                    if (downloaded && targetApk.exists() && targetApk.length() > 0L) {
                        prefs.edit().putString("fp_${targetApk.name}", fingerprint).apply()
                        exportToPublicDownloads(targetApk, appName)
                        notifyMediaScanner(targetApk)
                        mainHandler.post {
                            progressDialog.dismiss()
                            Toast.makeText(activity, "APK ready! Launching installer...", Toast.LENGTH_LONG).show()
                            launchPackageInstaller(targetApk)
                        }
                        return@thread
                    }
                }

                // 1. Prepare Payload
                val payload = JSONObject().apply {
                    put("app_name", appName)
                    put("package_id", packageId)
                    put("splash_color", splashColor)
                    put("icon_base64", iconBase64)
                    put("html_content", standaloneHtml)
                    put("project_zip_base64", projectZipBase64)
                    put("entry_file", entryFile)
                    put("permissions", org.json.JSONArray(permissions))
                    put("fingerprint", fingerprint)
                    put("project_type", projectType)
                }

                // 2. Check and Auto-Initialize GitHub Repository
                updateProgress(titleText, subtitleText, "Syncing Workflow", "Updating GitHub Actions workflow in your repository...")
                val workflowBytes = try {
                    activity.assets.open("workflow/build-standalone-apk.yml").use { it.readBytes() }
                } catch (e: Exception) {
                    null
                }
                if (workflowBytes != null) {
                    val uploaded = client.uploadFile(
                        ".github/workflows/build-standalone-apk.yml",
                        workflowBytes,
                        "Update Standalone APK Builder Workflow"
                    )
                    if (!uploaded && !client.checkWorkflowExists()) {
                        throw Exception("Failed to setup workflow in repository. Please ensure your token has 'workflow' and 'repo' permissions.")
                    }
                }

                // If template is missing in an empty repository, upload the project template (90 KB)
                if (client.getFileSha("app/build.gradle") == null) {
                    updateProgress(titleText, subtitleText, "Setting up Build Template", "Uploading Android app template to repository (90 KB)...")
                    val templateBytes = try {
                        activity.assets.open("template/project_template.zip").use { it.readBytes() }
                    } catch (e: Exception) {
                        null
                    }
                    if (templateBytes != null) {
                        client.uploadFile("build_payload/template.zip", templateBytes, "Add Standalone Project Template")
                    }
                }

                updateProgress(titleText, subtitleText, "Triggering GitHub Actions", "Uploading payload to cloud runner...")

                val uploaded = client.uploadBuildPayload(payload.toString())
                if (!uploaded) {
                    throw Exception("Failed to upload build payload to GitHub. Please check repository name and token permissions.")
                }

                // 3. Poll workflow status
                updateProgress(titleText, subtitleText, "Compiling Standalone APK", "GitHub Actions is compiling with Gradle...")

                var attempt = 0
                val startTime = System.currentTimeMillis()

                // Wait for the new run to appear and finish (up to 4 minutes)
                while (attempt < 48) {
                    Thread.sleep(5000)
                    attempt++
                    val elapsedSeconds = (System.currentTimeMillis() - startTime) / 1000
                    val run = client.getLatestWorkflowRun()

                    if (run != null) {
                        if (run.status == "completed") {
                            if (run.conclusion == "success") {
                                break
                            } else {
                                throw Exception("Build failed on GitHub Actions with status: ${run.conclusion}")
                            }
                        } else {
                            updateProgress(
                                titleText,
                                subtitleText,
                                "Compiling Standalone APK",
                                "Building Gradle project... (${elapsedSeconds}s elapsed)"
                            )
                        }
                    }
                }

                // 4. Fetch Release & Download APK into public Downloads folder
                updateProgress(titleText, subtitleText, "Downloading APK", "Fetching compiled APK from GitHub Release...")

                var downloadUrl = client.getReleaseDownloadUrl()
                var retries = 0
                while (downloadUrl == null && retries < 4) {
                    Thread.sleep(3000)
                    downloadUrl = client.getReleaseDownloadUrl()
                    retries++
                }

                val primaryUrl = downloadUrl ?: "https://github.com/${getRepo()}/releases/latest/download/standalone-app.apk"

                var downloaded = client.downloadApk(primaryUrl, targetApk) { percent ->
                    updateProgress(titleText, subtitleText, "Downloading APK ($percent%)", "Saving to Download/HTML_APK_Builds/${targetApk.name}...")
                }

                // Fallback to browser download permalink if API url failed
                if (!downloaded || !targetApk.exists() || targetApk.length() == 0L) {
                    val fallbackUrl = "https://github.com/${getRepo()}/releases/latest/download/standalone-app.apk"
                    downloaded = client.downloadApk(fallbackUrl, targetApk) { percent ->
                        updateProgress(titleText, subtitleText, "Downloading APK ($percent%)", "Saving to Download/HTML_APK_Builds/${targetApk.name}...")
                    }
                }

                if (!downloaded || !targetApk.exists() || targetApk.length() == 0L) {
                    throw Exception("Could not download compiled APK from GitHub. Please check network connection.")
                }

                // Save fingerprint for local instant cache
                prefs.edit().putString("fp_${targetApk.name}", fingerprint).apply()

                // Export copy to public Downloads if supported and notify scanner
                exportToPublicDownloads(targetApk, appName)
                notifyMediaScanner(targetApk)

                // 5. Success -> Prompt Install
                mainHandler.post {
                    progressDialog.dismiss()
                    Toast.makeText(activity, "APK ready! Launching installer...", Toast.LENGTH_LONG).show()
                    launchPackageInstaller(targetApk)
                }

            } catch (e: Exception) {
                mainHandler.post {
                    progressDialog.dismiss()
                    AlertDialog.Builder(activity)
                        .setTitle("Build Error")
                        .setMessage(e.message ?: "Unknown error occurred during build")
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }
    }

    private fun updateProgress(titleView: TextView, subtitleView: TextView, title: String, subtitle: String) {
        mainHandler.post {
            titleView.text = title
            subtitleView.text = subtitle
        }
    }

    private fun notifyMediaScanner(file: File) {
        try {
            MediaScannerConnection.scanFile(
                activity,
                arrayOf(file.absolutePath),
                arrayOf("application/vnd.android.package-archive"),
                null
            )
        } catch (_: Exception) {}
    }

    private fun launchPackageInstaller(apkFile: File) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!activity.packageManager.canRequestPackageInstalls()) {
                    val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                        data = Uri.parse("package:${activity.packageName}")
                    }
                    activity.startActivity(intent)
                    Toast.makeText(activity, "Please allow 'Install unknown apps' to install the APK", Toast.LENGTH_LONG).show()
                    return
                }
            }

            val apkUri = FileProvider.getUriForFile(
                activity,
                "${activity.packageName}.fileprovider",
                apkFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(activity, "Cannot open installer: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
