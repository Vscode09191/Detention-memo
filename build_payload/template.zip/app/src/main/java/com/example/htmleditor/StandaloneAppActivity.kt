package com.example.htmleditor

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class StandaloneAppActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var splashContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private var splashDismissed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Construct layout programmatically to eliminate any R.layout / R.id compile-time dependencies
        val density = resources.displayMetrics.density

        val rootLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        rootLayout.addView(webView)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                (3 * density).toInt()
            ).apply {
                gravity = Gravity.TOP
            }
            isIndeterminate = false
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#4FC3F7"))
            visibility = View.GONE
        }
        rootLayout.addView(progressBar)

        splashContainer = LinearLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }

        val splashIcon = ImageView(this).apply {
            val iconSize = (100 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
            try {
                setImageDrawable(packageManager.getApplicationIcon(applicationInfo))
            } catch (e: Exception) {
                // Fallback silently if icon cannot be loaded
            }
            contentDescription = "App Logo"
        }
        splashContainer.addView(splashIcon)

        val splashTitle = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (16 * density).toInt()
            }
            text = try {
                packageManager.getApplicationLabel(applicationInfo).toString()
            } catch (e: Exception) {
                "App"
            }
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        }
        splashContainer.addView(splashTitle)

        rootLayout.addView(splashContainer)

        setContentView(rootLayout)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowFileAccessFromFileURLs = true
        webView.settings.allowUniversalAccessFromFileURLs = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.setGeolocationEnabled(true)
        webView.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress >= 100) {
                    progressBar.visibility = View.GONE
                    dismissSplash()
                } else {
                    progressBar.visibility = View.VISIBLE
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: android.webkit.GeolocationPermissions.Callback?
            ) {
                // Grant HTML5 geolocation access to the web page
                callback?.invoke(origin, true, false)
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                // Grant camera / microphone WebRTC permissions
                request?.let { req ->
                    runOnUiThread {
                        req.grant(req.resources)
                    }
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                dismissSplash()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // Load standalone app bundled in assets or local directory
        val localHtml = java.io.File(filesDir, "standalone_app/index.html")
        if (localHtml.exists()) {
            webView.loadUrl("file://${localHtml.absolutePath}")
        } else {
            webView.loadUrl("file:///android_asset/standalone_app/index.html")
        }

        // Safety fallback: dismiss splash after 3 seconds even on slow scripts
        splashContainer.postDelayed({ dismissSplash() }, 3000)
    }

    private fun dismissSplash() {
        if (!splashDismissed) {
            splashDismissed = true
            val fadeOut = AlphaAnimation(1f, 0f).apply {
                duration = 400
                setAnimationListener(object : android.view.animation.Animation.AnimationListener {
                    override fun onAnimationStart(a: android.view.animation.Animation?) {}
                    override fun onAnimationEnd(a: android.view.animation.Animation?) {
                        splashContainer.visibility = View.GONE
                    }
                    override fun onAnimationRepeat(a: android.view.animation.Animation?) {}
                })
            }
            splashContainer.startAnimation(fadeOut)
        }
    }
}
