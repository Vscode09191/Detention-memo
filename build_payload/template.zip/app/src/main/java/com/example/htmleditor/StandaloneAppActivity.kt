package com.example.htmleditor

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class StandaloneAppActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var splashContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private var splashDismissed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Construct layout programmatically to eliminate any R.layout / R.id compile-time dependencies
        val density = resources.displayMetrics.density

        val rootLayout = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        rootLayout.addView(webView)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                (3 * density).toInt()
            ).apply {
                gravity = Gravity.TOP
            }
            isIndeterminate = false
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#4FC3F7"))
            visibility = View.GONE
        }
        rootLayout.addView(progressBar)

        splashContainer = LinearLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }

        val splashIcon = ImageView(this).apply {
            val iconSize = (100 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(iconSize, iconSize)
            try {
                setImageDrawable(packageManager.getApplicationIcon(applicationInfo))
            } catch (e: Exception) {
                // Fallback silently if icon cannot be loaded
            }
            contentDescription = "App Logo"
        }
        splashContainer.addView(splashIcon)

        val splashTitle = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (16 * density).toInt()
            }
            text = try {
                packageManager.getApplicationLabel(applicationInfo).toString()
            } catch (e: Exception) {
                "App"
            }
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        }
        splashContainer.addView(splashTitle)

        rootLayout.addView(splashContainer)

        setContentView(rootLayout)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowFileAccessFromFileURLs = true
        webView.settings.allowUniversalAccessFromFileURLs = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.setGeolocationEnabled(true)
        webView.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress >= 100) {
                    progressBar.visibility = View.GONE
                    dismissSplash()
                } else {
                    progressBar.visibility = View.VISIBLE
                }
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: android.webkit.GeolocationPermissions.Callback?
            ) {
                callback?.invoke(origin, true, false)
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                request?.let { req ->
                    runOnUiThread {
                        req.grant(req.resources)
                    }
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                dismissSplash()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // Smart HTML resolution: load index.html or auto-detect any HTML entry file
        findAndLoadHtml()

        // Safety fallback: dismiss splash after 3 seconds even on slow scripts
        splashContainer.postDelayed({ dismissSplash() }, 3000)
    }

    private fun findAndLoadHtml() {
        // 1. Check local files directory
        val localHtml = java.io.File(filesDir, "standalone_app/index.html")
        if (localHtml.exists()) {
            webView.loadUrl("file://${localHtml.absolutePath}")
            return
        }

        // 2. Search assets for standalone HTML
        val targetUrl = resolveAssetHtmlPath("standalone_app")
        if (targetUrl != null) {
            webView.loadUrl(targetUrl)
        } else {
            // 3. Fallback: Show clean page instead of ugly ERR_FILE_NOT_FOUND
            webView.loadDataWithBaseURL(
                null,
                "<!DOCTYPE html><html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><style>body{background:#121212;color:#fff;font-family:sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;margin:0;padding:20px;text-align:center;}h2{color:#4FC3F7;margin-bottom:8px;}p{color:#aaa;font-size:14px;}</style></head><body><h2>App Ready</h2><p>Application assets initialized.</p></body></html>",
                "text/html",
                "UTF-8",
                null
            )
        }
    }

    private fun resolveAssetHtmlPath(baseDir: String): String? {
        try {
            val list = assets.list(baseDir) ?: return null
            // Check direct index.html or index.htm
            if (list.contains("index.html")) {
                return "file:///android_asset/$baseDir/index.html"
            }
            if (list.contains("index.htm")) {
                return "file:///android_asset/$baseDir/index.htm"
            }
            // Check any other .html or .htm file in root
            val anyHtml = list.firstOrNull { it.endsWith(".html", ignoreCase = true) || it.endsWith(".htm", ignoreCase = true) }
            if (anyHtml != null) {
                return "file:///android_asset/$baseDir/$anyHtml"
            }
            // Check inside subfolders
            for (sub in list) {
                val subPath = if (baseDir.isEmpty()) sub else "$baseDir/$sub"
                val subList = try { assets.list(subPath) } catch (_: Exception) { null }
                if (!subList.isNullOrEmpty()) {
                    val subIndex = subList.firstOrNull { it.equals("index.html", ignoreCase = true) || it.equals("index.htm", ignoreCase = true) }
                        ?: subList.firstOrNull { it.endsWith(".html", ignoreCase = true) || it.endsWith(".htm", ignoreCase = true) }
                    if (subIndex != null) {
                        return "file:///android_asset/$subPath/$subIndex"
                    }
                }
            }
        } catch (_: Exception) {}
        return null
    }

    private fun dismissSplash() {
        if (!splashDismissed) {
            splashDismissed = true
            val fadeOut = AlphaAnimation(1f, 0f).apply {
                duration = 400
                setAnimationListener(object : android.view.animation.Animation.AnimationListener {
                    override fun onAnimationStart(a: android.view.animation.Animation?) {}
                    override fun onAnimationEnd(a: android.view.animation.Animation?) {
                        splashContainer.visibility = View.GONE
                    }
                    override fun onAnimationRepeat(a: android.view.animation.Animation?) {}
                })
            }
            splashContainer.startAnimation(fadeOut)
        }
    }
}
