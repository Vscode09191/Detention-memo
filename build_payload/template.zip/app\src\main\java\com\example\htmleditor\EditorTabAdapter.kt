package com.example.htmleditor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class EditorTabAdapter(
    private val openFiles: MutableList<File> = mutableListOf(),
    private var activeFile: File? = null,
    private val onTabClick: (File) -> Unit,
    private val onTabClose: (File) -> Unit
) : RecyclerView.Adapter<EditorTabAdapter.TabViewHolder>() {

    class TabViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val root: View = view.findViewById(R.id.tabRoot)
        val icon: TextView = view.findViewById(R.id.tabIcon)
        val name: TextView = view.findViewById(R.id.tabFileName)
        val btnClose: ImageView = view.findViewById(R.id.tabBtnClose)
    }

    fun setActiveFile(file: File?) {
        activeFile = file
        notifyDataSetChanged()
    }

    fun getActiveFile(): File? = activeFile

    fun getOpenFiles(): List<File> = openFiles

    fun addOrSelectTab(file: File) {
        val existingIndex = openFiles.indexOfFirst { it.absolutePath == file.absolutePath }
        if (existingIndex == -1) {
            openFiles.add(file)
        }
        activeFile = file
        notifyDataSetChanged()
    }

    fun removeTab(file: File): File? {
        val index = openFiles.indexOfFirst { it.absolutePath == file.absolutePath }
        if (index != -1) {
            val wasActive = activeFile?.absolutePath == file.absolutePath
            openFiles.removeAt(index)
            if (wasActive) {
                activeFile = if (openFiles.isNotEmpty()) {
                    val nextIndex = if (index < openFiles.size) index else openFiles.size - 1
                    openFiles[nextIndex]
                } else {
                    null
                }
            }
            notifyDataSetChanged()
            return activeFile
        }
        return activeFile
    }

    fun updateRenamedFile(oldFile: File, newFile: File) {
        val index = openFiles.indexOfFirst { it.absolutePath == oldFile.absolutePath }
        if (index != -1) {
            openFiles[index] = newFile
            if (activeFile?.absolutePath == oldFile.absolutePath) {
                activeFile = newFile
            }
            notifyDataSetChanged()
        }
    }

    fun clearTabs() {
        openFiles.clear()
        activeFile = null
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TabViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_editor_tab, parent, false)
        return TabViewHolder(view)
    }

    override fun onBindViewHolder(holder: TabViewHolder, position: Int) {
        val file = openFiles[position]
        val isActive = activeFile?.absolutePath == file.absolutePath

        holder.name.text = file.name
        holder.icon.text = iconFor(file.extension)

        if (isActive) {
            holder.root.setBackgroundResource(R.drawable.tab_active_bg)
            holder.name.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.white))
        } else {
            holder.root.setBackgroundResource(R.drawable.tab_inactive_bg)
            holder.name.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.tab_inactive_text))
        }

        holder.root.setOnClickListener {
            if (activeFile?.absolutePath != file.absolutePath) {
                onTabClick(file)
            }
        }

        holder.btnClose.setOnClickListener {
            onTabClose(file)
        }
    }

    override fun getItemCount(): Int = openFiles.size

    private fun iconFor(extension: String): String = when (extension.lowercase()) {
        "html", "htm" -> "🌐"
        "css" -> "🎨"
        "js" -> "⚙️"
        "json" -> "🗂️"
        "png", "jpg", "jpeg", "gif", "webp", "svg" -> "🖼️"
        else -> "📄"
    }
}
