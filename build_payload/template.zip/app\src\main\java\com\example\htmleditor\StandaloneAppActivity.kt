package com.example.htmleditor

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.view.animation.AlphaAnimation
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class StandaloneAppActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var splashContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private var splashDismissed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_standalone_app)

        webView = findViewById(R.id.standaloneWebView)
        splashContainer = findViewById(R.id.splashContainer)
        progressBar = findViewById(R.id.standaloneProgress)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowFileAccessFromFileURLs = true
        webView.settings.allowUniversalAccessFromFileURLs = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress >= 100) {
                    progressBar.visibility = View.GONE
                    dismissSplash()
                } else {
                    progressBar.visibility = View.VISIBLE
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                dismissSplash()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // Load standalone app bundled in assets or local directory
        val localHtml = java.io.File(filesDir, "standalone_app/index.html")
        if (localHtml.exists()) {
            webView.loadUrl("file://${localHtml.absolutePath}")
        } else {
            webView.loadUrl("file:///android_asset/standalone_app/index.html")
        }

        // Safety fallback: dismiss splash after 3 seconds even on slow scripts
        splashContainer.postDelayed({ dismissSplash() }, 3000)
    }

    private fun dismissSplash() {
        if (!splashDismissed) {
            splashDismissed = true
            val fadeOut = AlphaAnimation(1f, 0f).apply {
                duration = 400
                setAnimationListener(object : android.view.animation.Animation.AnimationListener {
                    override fun onAnimationStart(a: android.view.animation.Animation?) {}
                    override fun onAnimationEnd(a: android.view.animation.Animation?) {
                        splashContainer.visibility = View.GONE
                    }
                    override fun onAnimationRepeat(a: android.view.animation.Animation?) {}
                })
            }
            splashContainer.startAnimation(fadeOut)
        }
    }
}
