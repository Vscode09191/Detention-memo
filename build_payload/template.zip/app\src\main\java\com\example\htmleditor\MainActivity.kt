package com.example.htmleditor

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var projectManager: ProjectManager
    private lateinit var editorWebView: WebView
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var fileListRecyclerView: RecyclerView
    private lateinit var fileListAdapter: FileListAdapter
    private lateinit var tabRecyclerView: RecyclerView
    private lateinit var tabAdapter: EditorTabAdapter
    private lateinit var emptyTabsText: TextView
    private lateinit var standaloneApkBuilder: StandaloneApkBuilder

    private var currentOpenFile: File? = null
    private var editorReady = false
    private var pendingContentToLoad: Pair<String, String>? = null // content, lang

    // ---- Activity result launchers ----

    private val openZipLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { handleZipImport(it) }
    }

    private val openFilesLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) handleMultiFileImport(uris)
    }

    private val pickIconLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { standaloneApkBuilder.setPickedIcon(it) }
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projectManager = ProjectManager(this)
        standaloneApkBuilder = StandaloneApkBuilder(this).apply {
            onPickIconRequested = { pickIconLauncher.launch("image/*") }
        }

        drawerLayout = findViewById(R.id.drawerLayout)
        editorWebView = findViewById(R.id.editorWebView)
        fileListRecyclerView = findViewById(R.id.fileListRecyclerView)
        tabRecyclerView = findViewById(R.id.tabRecyclerView)
        emptyTabsText = findViewById(R.id.emptyTabsText)

        val topToolbar = findViewById<MaterialToolbar>(R.id.topToolbar)
        topToolbar.setNavigationOnClickListener {
            drawerLayout.openDrawer(androidx.core.view.GravityCompat.START)
        }
        topToolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_build_standalone_apk -> { promptBuildStandaloneApk(); true }
                R.id.action_github_settings -> { standaloneApkBuilder.showSettingsDialog(); true }
                R.id.action_save_as -> { saveAsCurrentFile(); true }
                R.id.action_copy_all -> { copyAllContent(); true }
                R.id.action_delete_all -> { deleteAllContent(); true }
                R.id.action_new_project -> { confirmNewProject(); true }
                R.id.action_rename -> { renameCurrentFile(); true }
                R.id.action_delete -> { deleteCurrentFile(); true }
                R.id.action_share_zip -> { exportProjectZip(); true }
                else -> false
            }
        }

        setupTabs()
        setupEditorWebView()
        setupFileList()
        setupBottomButtons()
        setupQuickInsertBar()

        // Load any existing project files on start
        refreshFileList()
        val existingFiles = projectManager.listProjectFiles()
        if (existingFiles.isNotEmpty()) {
            val main = projectManager.findMainHtmlFile() ?: existingFiles.first()
            openFileInEditor(main)
        } else {
            updateEmptyTabsState()
        }
    }

    // ================= Tab Bar setup =================

    private fun setupTabs() {
        tabAdapter = EditorTabAdapter(
            onTabClick = { file -> switchToFile(file) },
            onTabClose = { file -> closeTab(file) }
        )
        tabRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tabRecyclerView.adapter = tabAdapter
    }

    private fun updateEmptyTabsState() {
        if (tabAdapter.itemCount == 0) {
            emptyTabsText.visibility = View.VISIBLE
            tabRecyclerView.visibility = View.GONE
        } else {
            emptyTabsText.visibility = View.GONE
            tabRecyclerView.visibility = View.VISIBLE
        }
    }

    // ================= Editor WebView setup =================

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun setupEditorWebView() {
        editorWebView.isFocusable = true
        editorWebView.isFocusableInTouchMode = true
        editorWebView.settings.javaScriptEnabled = true
        editorWebView.settings.domStorageEnabled = true
        editorWebView.addJavascriptInterface(EditorBridge(), "AndroidBridge")
        editorWebView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                editorReady = true
                pendingContentToLoad?.let { (content, lang) ->
                    loadContentIntoEditor(content, lang)
                    pendingContentToLoad = null
                }
            }
        }

        editorWebView.setOnTouchListener { v, _ ->
            if (!v.hasFocus()) {
                v.requestFocus()
            }
            false
        }

        editorWebView.loadUrl("file:///android_asset/editor/index.html")
    }

    inner class EditorBridge {
        @JavascriptInterface
        fun onContentChanged() {
            // Unsaved indicator hook
        }
    }

    private fun loadContentIntoEditor(content: String, lang: String) {
        val escaped = org.json.JSONObject.quote(content)
        editorWebView.evaluateJavascript("setContent($escaped, '$lang')", null)
    }

    private fun getEditorContent(callback: (String) -> Unit) {
        editorWebView.evaluateJavascript("getContent()") { result ->
            val unquoted = try {
                org.json.JSONTokener(result).nextValue() as String
            } catch (e: Exception) {
                result.trim('"')
            }
            callback(unquoted)
        }
    }

    private fun langForFile(file: File): String = when (file.extension.lowercase()) {
        "css" -> "css"
        "js" -> "js"
        else -> "html"
    }

    // ================= File list (drawer) =================

    private fun setupFileList() {
        fileListAdapter = FileListAdapter(
            files = projectManager.listProjectFiles(),
            onFileClick = { file -> openFileInEditor(file); drawerLayout.closeDrawers() },
            onFileLongClick = { file -> showFileOptionsDialog(file); true }
        )
        fileListRecyclerView.layoutManager = LinearLayoutManager(this)
        fileListRecyclerView.adapter = fileListAdapter

        findViewById<MaterialButton>(R.id.btnOpenZip).setOnClickListener {
            openZipLauncher.launch("application/zip")
        }
        findViewById<MaterialButton>(R.id.btnOpenFiles).setOnClickListener {
            openFilesLauncher.launch("*/*")
        }
        findViewById<MaterialButton>(R.id.btnNewFile).setOnClickListener {
            promptNewFileName()
        }
    }

    private fun refreshFileList() {
        fileListAdapter.updateFiles(projectManager.listProjectFiles())
    }

    private fun showFileOptionsDialog(file: File) {
        val options = arrayOf("Open", "Rename", "Delete")
        AlertDialog.Builder(this)
            .setTitle(file.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { openFileInEditor(file); drawerLayout.closeDrawers() }
                    1 -> promptRename(file)
                    2 -> confirmDelete(file)
                }
            }
            .show()
    }

    private fun promptNewFileName() {
        val input = EditText(this)
        input.hint = "e.g. about.html, style.css, script.js"
        AlertDialog.Builder(this)
            .setTitle("New file name")
            .setView(wrapInputPadding(input))
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val file = projectManager.createNewFile(name)
                    refreshFileList()
                    openFileInEditor(file)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptRename(file: File) {
        val input = EditText(this)
        input.setText(file.name)
        AlertDialog.Builder(this)
            .setTitle("Rename file")
            .setView(wrapInputPadding(input))
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    val renamed = projectManager.renameFile(file, newName)
                    tabAdapter.updateRenamedFile(file, renamed)
                    if (currentOpenFile?.absolutePath == file.absolutePath) {
                        currentOpenFile = renamed
                    }
                    refreshFileList()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${file.name}?")
            .setMessage("This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                projectManager.deleteFile(file)
                closeTab(file)
                refreshFileList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun renameCurrentFile() {
        currentOpenFile?.let { promptRename(it) } ?: toast("Open a file first")
    }

    private fun deleteCurrentFile() {
        currentOpenFile?.let { confirmDelete(it) } ?: toast("Open a file first")
    }

    private fun wrapInputPadding(input: EditText): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        val padding = (16 * resources.displayMetrics.density).toInt()
        layout.setPadding(padding, padding / 2, padding, 0)
        layout.addView(input)
        return layout
    }

    private fun confirmNewProject() {
        AlertDialog.Builder(this)
            .setTitle("Start new project?")
            .setMessage("This will clear all current project files.")
            .setPositiveButton("Clear") { _, _ ->
                projectManager.clearProject()
                currentOpenFile = null
                tabAdapter.clearTabs()
                updateEmptyTabsState()
                loadContentIntoEditor("", "html")
                refreshFileList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ================= Standalone APK Builder =================

    private fun promptBuildStandaloneApk() {
        saveCurrentFileSilently {
            val mainHtml = resolvePreviewTarget()
            if (mainHtml == null) {
                toast("No HTML file found in project to build APK")
                return@saveCurrentFileSilently
            }
            standaloneApkBuilder.showBuildDialog(mainHtml, projectManager.projectRoot)
        }
    }

    // ================= Save As / Copy All / Delete All =================

    private fun saveAsCurrentFile() {
        val current = currentOpenFile
        if (current == null) {
            toast("No file open to save as")
            return
        }

        val dotIndex = current.name.lastIndexOf('.')
        val suggestedName = if (dotIndex != -1) {
            val base = current.name.substring(0, dotIndex)
            val ext = current.name.substring(dotIndex)
            "${base}_copy$ext"
        } else {
            "${current.name}_copy"
        }

        val input = EditText(this)
        input.setText(suggestedName)
        input.setSelection(suggestedName.length)

        AlertDialog.Builder(this)
            .setTitle("Save As")
            .setView(wrapInputPadding(input))
            .setPositiveButton("Save") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    getEditorContent { content ->
                        val newFile = projectManager.createNewFile(newName)
                        newFile.writeText(content)
                        refreshFileList()
                        openFileInEditor(newFile)
                        toast("Saved as $newName")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun copyAllContent() {
        if (currentOpenFile == null) {
            toast("No file open to copy")
            return
        }
        getEditorContent { content ->
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Editor Code", content)
            clipboard.setPrimaryClip(clip)
            toast("Copied all to clipboard (${content.length} chars)")
        }
    }

    private fun deleteAllContent() {
        if (currentOpenFile == null) {
            toast("No file open")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Delete All Content?")
            .setMessage("Are you sure you want to delete all text in this file? This cannot be undone.")
            .setPositiveButton("Delete All") { _, _ ->
                editorWebView.evaluateJavascript("clearContent()", null)
                currentOpenFile?.writeText("")
                toast("All content cleared")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ================= Tab & Editor Switching / Saving =================

    private fun openFileInEditor(file: File) {
        saveCurrentFileSilently {
            currentOpenFile = file
            tabAdapter.addOrSelectTab(file)
            updateEmptyTabsState()
            val position = tabAdapter.getOpenFiles().indexOfFirst { it.absolutePath == file.absolutePath }
            if (position != -1) {
                tabRecyclerView.smoothScrollToPosition(position)
            }
            val content = if (file.exists()) file.readText() else ""
            val lang = langForFile(file)
            if (editorReady) {
                loadContentIntoEditor(content, lang)
            } else {
                pendingContentToLoad = Pair(content, lang)
            }
        }
    }

    private fun switchToFile(file: File) {
        saveCurrentFileSilently {
            currentOpenFile = file
            tabAdapter.setActiveFile(file)
            val content = if (file.exists()) file.readText() else ""
            val lang = langForFile(file)
            if (editorReady) {
                loadContentIntoEditor(content, lang)
            } else {
                pendingContentToLoad = Pair(content, lang)
            }
        }
    }

    private fun closeTab(file: File) {
        val isClosingActive = currentOpenFile?.absolutePath == file.absolutePath
        if (isClosingActive) {
            saveCurrentFileSilently {
                val nextActive = tabAdapter.removeTab(file)
                updateEmptyTabsState()
                if (nextActive != null) {
                    currentOpenFile = nextActive
                    val content = if (nextActive.exists()) nextActive.readText() else ""
                    val lang = langForFile(nextActive)
                    if (editorReady) {
                        loadContentIntoEditor(content, lang)
                    } else {
                        pendingContentToLoad = Pair(content, lang)
                    }
                } else {
                    currentOpenFile = null
                    if (editorReady) {
                        loadContentIntoEditor("", "html")
                    }
                }
            }
        } else {
            tabAdapter.removeTab(file)
            updateEmptyTabsState()
        }
    }

    private fun saveCurrentFileSilently(afterSaved: (() -> Unit)? = null) {
        val file = currentOpenFile
        if (file == null) {
            afterSaved?.invoke()
            return
        }
        getEditorContent { content ->
            file.writeText(content)
            afterSaved?.invoke()
        }
    }

    private fun setupBottomButtons() {
        findViewById<MaterialButton>(R.id.btnOpen).setOnClickListener {
            drawerLayout.openDrawer(androidx.core.view.GravityCompat.START)
        }

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            val file = currentOpenFile
            if (file == null) {
                toast("No file open to save")
            } else {
                getEditorContent { content ->
                    file.writeText(content)
                    toast("Saved ${file.name}")
                }
            }
        }

        findViewById<MaterialButton>(R.id.btnPreviewApp).setOnClickListener {
            previewInApp()
        }

        findViewById<MaterialButton>(R.id.btnPreviewBrowser).setOnClickListener {
            previewInBrowser()
        }
    }

    private fun setupQuickInsertBar() {
        val bar = findViewById<LinearLayout>(R.id.quickInsertBar)
        bar.removeAllViews()

        // 1. Utility action buttons (Build APK, Save As, Copy All, Delete All)
        val actionButtons = listOf(
            Triple("🚀 Build APK", ContextCompat.getColor(this, R.color.accent)) { promptBuildStandaloneApk() },
            Triple("💾 Save As", ContextCompat.getColor(this, R.color.white)) { saveAsCurrentFile() },
            Triple("📋 Copy All", ContextCompat.getColor(this, R.color.white)) { copyAllContent() },
            Triple("🗑️ Delete All", ContextCompat.getColor(this, R.color.white)) { deleteAllContent() }
        )

        for ((label, textColor, action) in actionButtons) {
            val btn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            btn.text = label
            btn.textSize = 11f
            btn.setTextColor(textColor)
            btn.strokeColor = ContextCompat.getColorStateList(this, R.color.divider)
            btn.setPadding(16, 0, 16, 0)
            btn.isAllCaps = false
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.marginEnd = 6
            btn.layoutParams = params
            btn.setOnClickListener { action() }
            bar.addView(btn)
        }

        // 2. HTML snippet quick inserts
        val snippets = listOf(
            "<div></div>" to "<div>",
            "<h1></h1>" to "<h1>",
            "<p></p>" to "<p>",
            "<a href=\"\"></a>" to "<a>",
            "<img src=\"\">" to "<img>",
            "<span></span>" to "<span>",
            "<button></button>" to "<button>",
            "{ }" to "{ }",
            ";" to ";"
        )
        for ((snippet, label) in snippets) {
            val btn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            btn.text = label
            btn.textSize = 11f
            btn.setPadding(16, 0, 16, 0)
            btn.isAllCaps = false
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.marginEnd = 6
            btn.layoutParams = params
            btn.setOnClickListener {
                val escaped = org.json.JSONObject.quote(snippet)
                editorWebView.evaluateJavascript("insertAtCursor($escaped)", null)
            }
            bar.addView(btn)
        }
    }

    // ================= Preview =================

    private fun previewInApp() {
        saveCurrentFileSilently {
            val mainHtml = resolvePreviewTarget()
            if (mainHtml == null) {
                toast("No HTML file found in project")
                return@saveCurrentFileSilently
            }
            val intent = Intent(this, PreviewActivity::class.java)
            intent.putExtra(PreviewActivity.EXTRA_HTML_PATH, mainHtml.absolutePath)
            startActivity(intent)
        }
    }

    private fun previewInBrowser() {
        saveCurrentFileSilently {
            val mainHtml = resolvePreviewTarget()
            if (mainHtml == null) {
                toast("No HTML file found in project")
                return@saveCurrentFileSilently
            }
            try {
                val uri = FileProvider.getUriForFile(
                    this, "${packageName}.fileprovider", mainHtml
                )
                val intent = Intent(Intent.ACTION_VIEW)
                intent.setDataAndType(uri, "text/html")
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                toast("No browser app found to open the file")
            }
        }
    }

    /**
     * Decides which HTML file to preview: the currently open one if it's HTML,
     * otherwise the project's main/index.html.
     */
    private fun resolvePreviewTarget(): File? {
        val current = currentOpenFile
        if (current != null && (current.extension.equals("html", true) || current.extension.equals("htm", true))) {
            return current
        }
        return projectManager.findMainHtmlFile()
    }

    // ================= Import: ZIP & multi-file =================

    private fun handleZipImport(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zis ->
                    projectManager.extractZip(zis)
                }
            }
            refreshFileList()
            val main = projectManager.findMainHtmlFile()
            if (main != null) {
                openFileInEditor(main)
            }
            toast("ZIP imported successfully")
        } catch (e: Exception) {
            toast("Failed to import ZIP: ${e.message}")
        }
    }

    private fun handleMultiFileImport(uris: List<Uri>) {
        try {
            for (uri in uris) {
                val name = queryFileName(uri) ?: "file_${System.currentTimeMillis()}"
                projectManager.importSingleFile(name) {
                    contentResolver.openInputStream(uri) ?: throw Exception("Cannot open $uri")
                }
            }
            refreshFileList()
            val main = projectManager.findMainHtmlFile()
            if (main != null) {
                openFileInEditor(main)
            }
            toast("${uris.size} file(s) imported")
        } catch (e: Exception) {
            toast("Failed to import files: ${e.message}")
        }
    }

    private fun queryFileName(uri: Uri): String? {
        var name: String? = null
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && nameIndex >= 0) {
                name = it.getString(nameIndex)
            }
        }
        return name
    }

    // ================= Export =================

    private fun exportProjectZip() {
        saveCurrentFileSilently {
            try {
                val exportsDir = File(cacheDir, "exports").apply { mkdirs() }
                val zipFile = File(exportsDir, "project_export.zip")
                projectManager.exportProjectAsZip(zipFile)
                val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", zipFile)
                val intent = Intent(Intent.ACTION_SEND)
                intent.type = "application/zip"
                intent.putExtra(Intent.EXTRA_STREAM, uri)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(intent, "Share project ZIP"))
            } catch (e: Exception) {
                toast("Export failed: ${e.message}")
            }
        }
    }

    // ================= Utils =================

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onPause() {
        super.onPause()
        // Auto-save on pause so nothing is lost if the app is backgrounded
        saveCurrentFileSilently()
    }
}
